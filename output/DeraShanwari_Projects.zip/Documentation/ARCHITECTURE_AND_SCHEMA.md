# Dera Shanwari — Shared Architecture & Database Schema

All three Android applications share an identical domain model, repository interface layer, and Firebase Realtime Database schema contract so they synchronize seamlessly once connected to a live Firebase project.

---

## 1. Repository Architecture

All UI components (Activities, Fragments, Adapters) depend **only** on repository interfaces accessed via `RepositoryProvider`:

| Interface | Demo Implementation | Responsibilities |
|---|---|---|
| `AuthRepository` | `DemoAuthRepository` | Admin PIN login, Customer OTP send/verify, Rider PIN login, active session lookup, logout |
| `ProductRepository` | `DemoProductRepository` | Product CRUD, Category CRUD, Banner CRUD |
| `OrderRepository` | `DemoOrderRepository` | Order creation, status updates, rider assignment, payment recording & verification |
| `RiderRepository` | `DemoRiderRepository` | Rider list, create/update/toggle active status, delivery stats & earnings updates |
| `CustomerRepository` | `DemoCustomerRepository` | Customer directory, profile/address updates, reward points & redemption offers |
| `SettingsRepository` | `DemoSettingsRepository` | Restaurant info, opening hours, delivery fee, payment method configs (`COD`, `JazzCash`, `EasyPaisa`) |
| `ChatRepository` | `DemoChatRepository` | Per-order messaging stream between Customer, Admin, and Rider |

### Local Demo Persistence (`DemoDatabaseManager`)
- Stored in Android `SharedPreferences` (`"dera_shanwari_demo_db"`, key `"db_state_v1"`) serialized with `Gson`.
- Auto-seeds rich Peshawar menu items, categories, banners, riders, customers, payment configs, sample orders (`ORD-1001`..`ORD-1004`), rewards, and order chats on first launch.
- Changes made at runtime persist across app restarts and can be restored anytime via Admin -> Settings -> Reset Demo Data.

---

## 2. Shared Data Models (`model/`)

- `OrderStatus` (constants): `PENDING`, `CONFIRMED`, `PREPARING`, `READY`, `ASSIGNED`, `PICKED_UP`, `OUT_FOR_DELIVERY`, `DELIVERED`, `CANCELLED`
- `Product`: `id`, `name`, `description`, `price`, `discountPrice`, `imageUrl`, `localDrawableName`, `categoryId`, `categoryName`, `available`, `featured`, `popular`, `createdAt`
- `Category`: `id`, `name`, `imageUrl`, `localDrawableName`, `available`, `sortOrder`
- `Banner`: `id`, `title`, `subtitle`, `imageUrl`, `localDrawableName`, `active`, `sortOrder`
- `Customer`: `id`, `name`, `phone`, `address`, `active`, `rewardPoints`, `createdAt`
- `AdminUser`: `id`, `name`, `email`, `phone`, `role`, `active`
- `Rider`: `id`, `name`, `phone`, `vehicleInfo`, `profileImageUrl`, `active`, `totalDeliveries`, `totalEarnings`
- `OrderItem`: `productId`, `productName`, `unitPrice`, `quantity`, `notes`, `imageUrl`
- `Order`: `orderId`, `customerId`, `customerName`, `customerPhone`, `deliveryAddress`, `notes`, `items`, `subtotal`, `deliveryFee`, `totalAmount`, `paymentMethod`, `paymentStatus`, `orderStatus`, `riderId`, `riderName`, `createdAt`, `updatedAt`, `pointsEarned`
- `Payment`: `id`, `orderId`, `method`, `accountTitle`, `accountNumber`, `amount`, `status`, `timestamp`
- `PaymentMethodConfig`: `methodCode` (`COD`, `JAZZCASH`, `EASYPAISA`), `displayName`, `accountTitle`, `accountNumber`, `enabled`, `instructions`
- `RestaurantSettings`: `restaurantName`, `logoUrl`, `phone`, `whatsappNumber`, `address`, `openingHours`, `closingHours`, `deliveryCharges`, `minimumOrderAmount`, `pointsPerHundredRs`
- `Reward`: `id`, `customerId`, `title`, `description`, `points`, `type`, `active`, `costPoints`, `orderId`, `timestamp`
- `ChatMessage`: `id`, `orderId`, `senderId`, `senderRole`, `senderName`, `text`, `timestamp`

---

## 3. Firebase Realtime Database JSON Schema

Node constants are centrally defined in `firebase/FirebaseConfig.java`:

```json
{
  "restaurant_settings": {
    "restaurantName": "Dera Shanwari",
    "logoUrl": "https://ik.imagekit.io/derashanwari/brand/logo.png",
    "phone": "03001112233",
    "whatsappNumber": "923001112233",
    "address": "Main University Road, Tehkal, Peshawar",
    "openingHours": "12:00 PM",
    "closingHours": "12:30 AM",
    "deliveryCharges": 150,
    "minimumOrderAmount": 500,
    "pointsPerHundredRs": 10
  },
  "categories": {
    "cat_karahi": { "id": "cat_karahi", "name": "Karahi", "imageUrl": "...", "available": true, "sortOrder": 1 }
  },
  "products": {
    "prod_1": { "id": "prod_1", "name": "Mutton Shanwari Karahi (1 Kg)", "price": 3400, "discountPrice": 3150, "categoryId": "cat_karahi", "available": true, "featured": true, "popular": true }
  },
  "banners": {
    "ban_1": { "id": "ban_1", "title": "Signature Mutton Shanwari Karahi", "active": true, "sortOrder": 1 }
  },
  "customers": {
    "<uid>": { "id": "<uid>", "name": "Usman Tariq", "phone": "03009876543", "address": "...", "active": true, "rewardPoints": 240 }
  },
  "admins": {
    "<uid>": { "id": "<uid>", "name": "Tariq Shanwari", "email": "admin@derashanwari.pk", "role": "Owner", "active": true }
  },
  "riders": {
    "<uid>": { "id": "<uid>", "name": "Bilal Khan", "phone": "03125556677", "vehicleInfo": "Honda CD-70", "active": true, "totalDeliveries": 18, "totalEarnings": 5400 }
  },
  "orders": {
    "ORD-1001": { "orderId": "ORD-1001", "customerId": "<uid>", "riderId": "<rider_uid>", "orderStatus": "ASSIGNED", "paymentMethod": "COD", "paymentStatus": "Pending", "totalAmount": 1930, "items": [] }
  },
  "payments": {
    "pay_1": { "id": "pay_1", "orderId": "ORD-1001", "method": "COD", "amount": 1930, "status": "Pending" }
  },
  "payment_methods": {
    "COD": { "methodCode": "COD", "displayName": "Cash on Delivery", "enabled": true },
    "JAZZCASH": { "methodCode": "JAZZCASH", "displayName": "JazzCash", "accountNumber": "0300-1112233", "enabled": true },
    "EASYPAISA": { "methodCode": "EASYPAISA", "displayName": "EasyPaisa", "accountNumber": "0345-8889900", "enabled": true }
  },
  "rewards": {
    "offers": {},
    "history": {}
  },
  "order_chats": {
    "ORD-1003": {
      "msg_1": { "id": "msg_1", "senderId": "admin_1", "senderRole": "ADMIN", "text": "..." }
    }
  }
}
```

### Recommended Realtime Database Security Rules (Production)

```json
{
  "rules": {
    "restaurant_settings": { ".read": true, ".write": "root.child('admins').child(auth.uid).child('active').val() === true" },
    "categories": { ".read": true, ".write": "root.child('admins').child(auth.uid).child('active').val() === true" },
    "products": { ".read": true, ".write": "root.child('admins').child(auth.uid).child('active').val() === true" },
    "banners": { ".read": true, ".write": "root.child('admins').child(auth.uid).child('active').val() === true" },
    "payment_methods": { ".read": true, ".write": "root.child('admins').child(auth.uid).child('active').val() === true" },
    "admins": {
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        ".write": false
      }
    },
    "customers": {
      "$uid": {
        ".read": "auth != null && (auth.uid === $uid || root.child('admins').child(auth.uid).child('active').val() === true)",
        ".write": "auth != null && (auth.uid === $uid || root.child('admins').child(auth.uid).child('active').val() === true)"
      }
    },
    "riders": {
      "$uid": {
        ".read": "auth != null && (auth.uid === $uid || root.child('admins').child(auth.uid).child('active').val() === true)",
        ".write": "auth != null && root.child('admins').child(auth.uid).child('active').val() === true"
      }
    },
    "orders": {
      ".read": "auth != null",
      "$orderId": {
        ".write": "auth != null && (root.child('admins').child(auth.uid).child('active').val() === true || newData.child('customerId').val() === auth.uid || data.child('riderId').val() === auth.uid)"
      }
    }
  }
}
```
