# Firebase & ImageKit Production Integration Guide

All three Dera Shanwari applications are pre-architected for **Firebase Authentication**, **Firebase Realtime Database**, **Firebase Cloud Messaging (FCM)**, and **ImageKit CDN** without exposing private credentials or requiring custom backend servers.

---

## Part A: Connecting Firebase (Shared Across All 3 Apps)

### Step 1: Create One Firebase Project
1. Go to the [Firebase Console](https://console.firebase.google.com/) and create a project (e.g., `dera-shanwari-prod`).
2. Register **three Android apps** inside the same Firebase project:
   - `com.derashanwari.admin` (Admin App)
   - `com.derashanwari.user` (Customer App)
   - `com.derashanwari.rider` (Rider App)
3. Download each app's `google-services.json` and place it in that app's `app/` directory:
   - `output/Source/Admin/app/google-services.json`
   - `output/Source/Customer/app/google-services.json`
   - `output/Source/Rider/app/google-services.json`

### Step 2: Enable Firebase Services
1. **Authentication:**
   - Enable **Email/Password** (for Admin accounts).
   - Enable **Phone** sign-in (for Customer OTP and Rider login).
2. **Realtime Database:**
   - Create a Realtime Database instance in your preferred region.
   - Import or publish the security rules from `ARCHITECTURE_AND_SCHEMA.md`.
   - Seed `admins/<admin_uid>` with `active: true` for your owner account.
3. **Cloud Messaging (FCM):**
   - Enabled automatically with Firebase; configure topics using constants in `FirebaseConfig.java`:
     - `admin_new_orders`
     - `customer_<customerId>`
     - `rider_<riderId>`

### Step 3: Enable Gradle Plugins & Dependencies
In each project's root `build.gradle.kts` (or Version Catalog), ensure the Google Services plugin is available:
```kotlin
plugins {
    alias(libs.plugins.android.application) apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
}
```
Then inside each app's `app/build.gradle.kts`, uncomment:
1. `id("com.google.gms.google-services")` in `plugins { ... }`
2. The Firebase BOM & SDK lines in `dependencies { ... }`:
   ```kotlin
   implementation(platform("com.google.firebase:firebase-bom:33.10.0"))
   implementation("com.google.firebase:firebase-auth")
   implementation("com.google.firebase:firebase-database")
   implementation("com.google.firebase:firebase-messaging")
   ```

### Step 4: Switch from Demo Mode to Live Repositories
1. Create Firebase implementations (`FirebaseAuthRepository`, `FirebaseProductRepository`, `FirebaseOrderRepository`, etc.) implementing the existing `repository/*Repository.java` interfaces using `FirebaseConfig.NODE_*` paths via `FirebaseRealtimeDbBridge`.
2. Set `FirebaseConfig.DEMO_MODE = false`.
3. Update `RepositoryProvider.java` in each app to return the `Firebase*Repository` implementations when `FirebaseConfig.DEMO_MODE` is `false`.
4. Connect `FcmNotificationBridge` to your `FirebaseMessagingService` subclass and `AndroidManifest.xml` service entry for real-time order alerts.

---

## Part B: ImageKit Image Hosting Setup

Dera Shanwari uses **ImageKit.io** URLs stored directly inside `Product`, `Category`, `Banner`, and `RestaurantSettings` records—eliminating the need for Firebase Storage.

### Security Rule
> **NEVER** embed your ImageKit **Private API Key** inside any Android APK. Only store your public ImageKit URL endpoint and upload media from the ImageKit Dashboard (or a trusted admin upload flow using short-lived server signatures if added later).

### Setup Steps
1. Create an ImageKit.io account and note your public URL endpoint (e.g. `https://ik.imagekit.io/your_id/`).
2. Update `ImageKitConfig.BASE_CDN_ENDPOINT` in `config/ImageKitConfig.java`:
   ```java
   public static final String BASE_CDN_ENDPOINT = "https://ik.imagekit.io/your_id/";
   ```
3. Upload menu, category, and promotional banner assets into folders matching `ImageKitConfig`:
   - `products/`
   - `categories/`
   - `banners/`
   - `brand/`
4. Paste the resulting public `https://ik.imagekit.io/...` URLs directly in the **Admin App** when adding/editing products, categories, banners, or restaurant logo.
5. `ImageKitConfig.buildTransformedUrl(rawUrl, widthPx, heightPx)` automatically appends responsive ImageKit query transforms (`?tr=w-...,h-...,fo-auto,q-80`), and `ImageLoaderUtil` loads and caches images via Glide with bundled food/brand fallbacks when offline or in demo mode.
