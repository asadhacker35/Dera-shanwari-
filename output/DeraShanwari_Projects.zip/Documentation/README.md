# Dera Shanwari — Android Suite Documentation

Three independent native Android applications (**Java + XML**) built for **Dera Shanwari** restaurant operations, online ordering, and last-mile rider delivery.

---

## 1. Applications & Package Names

| App | Package / Application ID | Entry Launcher Activity | APK Output |
|---|---|---|---|
| **Admin Management App** | `com.derashanwari.admin` | `.ui.AdminSplashActivity` | `output/APK/Admin.apk` |
| **Customer App** | `com.derashanwari.user` | `.ui.SplashActivity` | `output/APK/Customer.apk` |
| **Rider App** | `com.derashanwari.rider` | `.ui.RiderSplashActivity` | `output/APK/Rider.apk` |

### Technology Stack
- **Language:** 100% Java (zero Kotlin application code)
- **UI Framework:** Android XML Layouts, Material Design Components (`com.google.android.material:material:1.12.0`), ViewBinding, RecyclerView, CardView, ConstraintLayout, SwipeRefreshLayout
- **SDK Levels:** `minSdk = 23`, `compileSdk = 36`, `targetSdk = 36`
- **Build System:** Gradle Kotlin DSL (`build.gradle.kts`) with Version Catalog (`gradle/libs.versions.toml`)
- **Core Libraries:** AndroidX AppCompat `1.7.0`, Gson `2.11.0`, Glide `4.16.0`
- **Testing:** JUnit 4 + AndroidX Test + Robolectric `4.16.1`

---

## 2. Output Directory Structure

```text
output/
├── APK/
│   ├── Admin.apk
│   ├── Customer.apk
│   └── Rider.apk
├── Documentation/
│   ├── README.md
│   ├── ARCHITECTURE_AND_SCHEMA.md
│   └── FIREBASE_AND_IMAGEKIT_GUIDE.md
├── Resources/
│   ├── icons/
│   ├── images/
│   └── vectors/
├── Source/
│   ├── Admin/
│   ├── Customer/
│   └── Rider/
└── DeraShanwari_Projects.zip
```

---

## 3. Demo Backend Credentials

All three applications ship in **Demo Mode** (`FirebaseConfig.DEMO_MODE = true`) backed by local persistent JSON storage (`SharedPreferences` + `Gson` in `DemoDatabaseManager`), allowing instant testing without external credentials.

### Admin App (`com.derashanwari.admin`)
- **Email / Phone:** `admin@derashanwari.pk` (or `03001112233`)
- **Demo PIN:** `123456`
- *Quick Demo Login button is also available on the login screen.*

### Customer App (`com.derashanwari.user`)
- **Existing Demo Accounts:**
  - `03009876543` — Usman Tariq (240 reward points, pre-seeded orders)
  - `03331234567` — Ayesha Khan (120 reward points)
  - `03457654321` — Saad Afridi (65 reward points)
- **New Registration:** Any valid Pakistani mobile number (`03XX-XXXXXXX`)
- **Demo OTP:** `1234`
- *Guest browsing is supported; checkout prompts OTP sign-in if not already logged in.*

### Rider App (`com.derashanwari.rider`)
- **Demo Riders:**
  - `03125556677` — Bilal Khan (Active, pre-assigned `ORD-1003`)
  - `03214445566` — Hamza Afridi (Active)
  - `03337778899` — Zain Abbas (Inactive account — tests deactivated guard)
- **Demo PIN:** `1234`
- *Quick Demo Login button is also available on the login screen.*

---

## 4. Feature Summary

### Admin Management App
- **Dashboard:** Order totals (pending, processing, completed, cancelled), total revenue, today's sales, customer & rider counts, quick navigation.
- **Orders:** Filterable order queue, status lifecycle updates (`PENDING -> CONFIRMED -> PREPARING -> ASSIGNED -> OUT_FOR_DELIVERY -> DELIVERED` or `CANCELLED`), rider assignment, payment verification (`Paid`, `Pending Verification`, `Failed`), order chat replies.
- **Catalog:** Full CRUD for Products (name, description, price, discount price, ImageKit URL, category, availability, featured toggle), Categories, and Promotional Banners.
- **People:** Manage Riders (create/edit, toggle active status, view completed deliveries & earnings) and Customers (view profile/points, suspend/activate).
- **More / Operations:** Payment method configuration (`COD`, `JazzCash`, `EasyPaisa`), payment ledger verification, sales reports & top-selling items, restaurant profile/hours/delivery fee settings, and demo data reset.

### Customer App
- **Home:** Branded header, promotional banner carousel, search bar, category quick chips, featured & popular dishes with discount badges.
- **Menu:** Category filtering, live search, sort/availability indicators, quick add-to-cart, product detail sheet with quantity & cooking notes.
- **Cart & Checkout:** Persistent cart items, quantity stepper, promo/reward points redemption, delivery fee calculation, `COD` / `JazzCash` / `EasyPaisa` instructions, WhatsApp payment proof / support shortcut, and order placement.
- **Orders & Tracking:** Live status timeline, item summary, assigned rider details, one-tap Call / WhatsApp support, and in-order chat feed.
- **Rewards & Account:** Points balance, redeemable offers (`150`, `220`, `400` pts), earned history, profile & delivery address editing, logout.

### Rider App
- **Dashboard:** Active/completed summary, rider earnings snapshot, availability badge, latest assigned delivery card.
- **Deliveries Queue:** Assigned and available/completed delivery history with order value, payment method, and customer address.
- **Delivery Detail:** Customer info, one-tap Dial / WhatsApp actions, itemized list, status transition buttons (`OUT_FOR_DELIVERY` / `DELIVERED`), COD payment collection confirmation, and customer/admin chat notes.
- **Profile:** Rider vehicle details, stats, and logout.

---

## 5. Building & Installing APKs

### Build & Run Tests from Source (per App)
Run Gradle inside any standalone project directory (`output/Source/Admin`, `output/Source/Customer`, or `output/Source/Rider`):

```bash
cd output/Source/Admin
gradle assembleDebug testDebugUnitTest
```

Outputs are generated at:
`app/build/outputs/apk/debug/app-debug.apk`

### Install Pre-built APKs via ADB
```bash
adb install -r output/APK/Admin.apk
adb install -r output/APK/Customer.apk
adb install -r output/APK/Rider.apk
```
Because all three apps use distinct `applicationId`s (`com.derashanwari.admin`, `com.derashanwari.user`, `com.derashanwari.rider`), all three can be installed side-by-side on the same Android device or emulator.
