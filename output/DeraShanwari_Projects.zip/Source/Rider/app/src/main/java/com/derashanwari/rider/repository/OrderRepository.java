package com.derashanwari.rider.repository;

import com.derashanwari.rider.model.Order;
import com.derashanwari.rider.model.Payment;

import java.util.List;

public interface OrderRepository {
    List<Order> getAllOrders();
    List<Order> getOrdersByCustomer(String customerId);
    List<Order> getOrdersByRider(String riderId);
    List<Order> getOrdersByStatus(String status);
    Order getOrderById(String orderId);

    Order placeOrder(Order order);
    boolean updateOrderStatus(String orderId, String newStatus);
    boolean assignRider(String orderId, String riderId, String riderName);

    List<Payment> getAllPayments();
    void recordPayment(Payment payment);
    boolean updatePaymentStatus(String paymentId, String status);
}
