package com.derashanwari.rider.model;

import java.io.Serializable;

public class Rider implements Serializable {
    private String id;
    private String name;
    private String phone;
    private String vehicleInfo;
    private String profileImageUrl;
    private boolean active;
    private int totalDeliveries;
    private double totalEarnings;

    public Rider() {}

    public Rider(String id, String name, String phone, String vehicleInfo, String profileImageUrl,
                 boolean active, int totalDeliveries, double totalEarnings) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.vehicleInfo = vehicleInfo;
        this.profileImageUrl = profileImageUrl;
        this.active = active;
        this.totalDeliveries = totalDeliveries;
        this.totalEarnings = totalEarnings;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getVehicleInfo() { return vehicleInfo; }
    public void setVehicleInfo(String vehicleInfo) { this.vehicleInfo = vehicleInfo; }

    public String getProfileImageUrl() { return profileImageUrl; }
    public void setProfileImageUrl(String profileImageUrl) { this.profileImageUrl = profileImageUrl; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    public int getTotalDeliveries() { return totalDeliveries; }
    public void setTotalDeliveries(int totalDeliveries) { this.totalDeliveries = totalDeliveries; }

    public double getTotalEarnings() { return totalEarnings; }
    public void setTotalEarnings(double totalEarnings) { this.totalEarnings = totalEarnings; }
}
