package com.derashanwari.rider.repository;

import android.content.Context;

import com.derashanwari.rider.repository.demo.DemoAuthRepository;
import com.derashanwari.rider.repository.demo.DemoChatRepository;
import com.derashanwari.rider.repository.demo.DemoCustomerRepository;
import com.derashanwari.rider.repository.demo.DemoDatabaseManager;
import com.derashanwari.rider.repository.demo.DemoOrderRepository;
import com.derashanwari.rider.repository.demo.DemoProductRepository;
import com.derashanwari.rider.repository.demo.DemoRiderRepository;
import com.derashanwari.rider.repository.demo.DemoSettingsRepository;

/**
 * Central service locator for all repositories.
 * Currently supplies Demo implementations backed by DemoDatabaseManager.
 * Swap to Firebase implementations when Firebase Realtime Database is connected.
 */
public final class RepositoryProvider {
    private static AuthRepository authRepository;
    private static ProductRepository productRepository;
    private static OrderRepository orderRepository;
    private static RiderRepository riderRepository;
    private static CustomerRepository customerRepository;
    private static SettingsRepository settingsRepository;
    private static ChatRepository chatRepository;

    private RepositoryProvider() {}

    public static synchronized void init(Context context) {
        DemoDatabaseManager.getInstance(context.getApplicationContext());
    }

    public static synchronized AuthRepository auth(Context context) {
        if (authRepository == null) {
            authRepository = new DemoAuthRepository(DemoDatabaseManager.getInstance(context));
        }
        return authRepository;
    }

    public static synchronized ProductRepository products(Context context) {
        if (productRepository == null) {
            productRepository = new DemoProductRepository(DemoDatabaseManager.getInstance(context));
        }
        return productRepository;
    }

    public static synchronized OrderRepository orders(Context context) {
        if (orderRepository == null) {
            orderRepository = new DemoOrderRepository(DemoDatabaseManager.getInstance(context));
        }
        return orderRepository;
    }

    public static synchronized RiderRepository riders(Context context) {
        if (riderRepository == null) {
            riderRepository = new DemoRiderRepository(DemoDatabaseManager.getInstance(context));
        }
        return riderRepository;
    }

    public static synchronized CustomerRepository customers(Context context) {
        if (customerRepository == null) {
            customerRepository = new DemoCustomerRepository(DemoDatabaseManager.getInstance(context));
        }
        return customerRepository;
    }

    public static synchronized SettingsRepository settings(Context context) {
        if (settingsRepository == null) {
            settingsRepository = new DemoSettingsRepository(DemoDatabaseManager.getInstance(context));
        }
        return settingsRepository;
    }

    public static synchronized ChatRepository chat(Context context) {
        if (chatRepository == null) {
            chatRepository = new DemoChatRepository(DemoDatabaseManager.getInstance(context));
        }
        return chatRepository;
    }

    public static synchronized void resetForTests() {
        authRepository = null;
        productRepository = null;
        orderRepository = null;
        riderRepository = null;
        customerRepository = null;
        settingsRepository = null;
        chatRepository = null;
    }
}
