package com.derashanwari.rider.model;

import java.util.Arrays;
import java.util.List;

public final class OrderStatus {
    public static final String PENDING = "Pending";
    public static final String CONFIRMED = "Confirmed";
    public static final String PREPARING = "Preparing";
    public static final String READY = "Ready";
    public static final String ASSIGNED = "Assigned";
    public static final String PICKED_UP = "Picked Up";
    public static final String OUT_FOR_DELIVERY = "Out for Delivery";
    public static final String DELIVERED = "Delivered";
    public static final String CANCELLED = "Cancelled";

    private OrderStatus() {}

    public static List<String> allAdminStatuses() {
        return Arrays.asList(
                PENDING, CONFIRMED, PREPARING, READY,
                ASSIGNED, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
        );
    }

    public static List<String> riderProgressionStatuses() {
        return Arrays.asList(ASSIGNED, PICKED_UP, OUT_FOR_DELIVERY, DELIVERED);
    }

    public static List<String> customerTrackingSteps() {
        return Arrays.asList(
                PENDING, CONFIRMED, PREPARING, READY,
                ASSIGNED, OUT_FOR_DELIVERY, DELIVERED
        );
    }

    public static boolean isCompletedOrCancelled(String status) {
        return DELIVERED.equalsIgnoreCase(status) || CANCELLED.equalsIgnoreCase(status);
    }
}
