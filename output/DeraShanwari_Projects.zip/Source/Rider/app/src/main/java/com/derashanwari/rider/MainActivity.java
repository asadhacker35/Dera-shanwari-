package com.derashanwari.rider;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.derashanwari.rider.repository.RepositoryProvider;
import com.derashanwari.rider.ui.fragment.RiderDashboardFragment;
import com.derashanwari.rider.ui.fragment.RiderOrdersFragment;
import com.derashanwari.rider.ui.fragment.RiderProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_main);
        RepositoryProvider.init(this);

        BottomNavigationView nav = findViewById(R.id.rider_bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_rider_dashboard) {
                load(new RiderDashboardFragment());
                return true;
            } else if (id == R.id.nav_rider_orders) {
                load(RiderOrdersFragment.newInstance(false));
                return true;
            } else if (id == R.id.nav_rider_history) {
                load(RiderOrdersFragment.newInstance(true));
                return true;
            } else if (id == R.id.nav_rider_profile) {
                load(new RiderProfileFragment());
                return true;
            }
            return false;
        });

        if (savedInstanceState == null) {
            nav.setSelectedItemId(R.id.nav_rider_dashboard);
        }
    }

    private void load(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.rider_fragment_container, fragment)
                .commit();
    }
}
