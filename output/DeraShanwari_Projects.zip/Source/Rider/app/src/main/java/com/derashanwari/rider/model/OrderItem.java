package com.derashanwari.rider.model;

import java.io.Serializable;

public class OrderItem implements Serializable {
    private String productId;
    private String productName;
    private double unitPrice;
    private int quantity;
    private String imageUrl;
    private String localDrawableName;

    public OrderItem() {}

    public OrderItem(String productId, String productName, double unitPrice, int quantity,
                     String imageUrl, String localDrawableName) {
        this.productId = productId;
        this.productName = productName;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.imageUrl = imageUrl;
        this.localDrawableName = localDrawableName;
    }

    public double getLineTotal() {
        return unitPrice * quantity;
    }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getLocalDrawableName() { return localDrawableName; }
    public void setLocalDrawableName(String localDrawableName) { this.localDrawableName = localDrawableName; }
}
