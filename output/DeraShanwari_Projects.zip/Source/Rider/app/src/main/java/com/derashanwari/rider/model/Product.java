package com.derashanwari.rider.model;

import java.io.Serializable;

public class Product implements Serializable {
    private String id;
    private String name;
    private String description;
    private double price;
    private double discountPrice;
    private String imageUrl;
    private String localDrawableName;
    private String categoryId;
    private String categoryName;
    private boolean available;
    private boolean featured;
    private boolean popular;
    private long createdAt;

    public Product() {}

    public Product(String id, String name, String description, double price, double discountPrice,
                   String imageUrl, String localDrawableName, String categoryId, String categoryName,
                   boolean available, boolean featured, boolean popular, long createdAt) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.discountPrice = discountPrice;
        this.imageUrl = imageUrl;
        this.localDrawableName = localDrawableName;
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.available = available;
        this.featured = featured;
        this.popular = popular;
        this.createdAt = createdAt;
    }

    public double getEffectivePrice() {
        return (discountPrice > 0 && discountPrice < price) ? discountPrice : price;
    }

    public boolean hasDiscount() {
        return discountPrice > 0 && discountPrice < price;
    }

    public int getDiscountPercent() {
        if (!hasDiscount() || price <= 0) return 0;
        return (int) Math.round(((price - discountPrice) / price) * 100.0);
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public double getDiscountPrice() { return discountPrice; }
    public void setDiscountPrice(double discountPrice) { this.discountPrice = discountPrice; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getLocalDrawableName() { return localDrawableName; }
    public void setLocalDrawableName(String localDrawableName) { this.localDrawableName = localDrawableName; }

    public String getCategoryId() { return categoryId; }
    public void setCategoryId(String categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    public boolean isFeatured() { return featured; }
    public void setFeatured(boolean featured) { this.featured = featured; }

    public boolean isPopular() { return popular; }
    public void setPopular(boolean popular) { this.popular = popular; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
}
