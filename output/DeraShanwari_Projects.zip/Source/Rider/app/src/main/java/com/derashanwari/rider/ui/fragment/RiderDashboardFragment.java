package com.derashanwari.rider.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.derashanwari.rider.R;
import com.derashanwari.rider.model.Order;
import com.derashanwari.rider.model.OrderStatus;
import com.derashanwari.rider.model.Rider;
import com.derashanwari.rider.repository.RepositoryProvider;
import com.derashanwari.rider.ui.RiderDeliveryDetailActivity;
import com.derashanwari.rider.ui.adapter.RiderOrderAdapter;
import com.derashanwari.rider.util.CurrencyUtil;

import java.util.ArrayList;
import java.util.List;

public class RiderDashboardFragment extends Fragment {
    private TextView tvWelcome, tvEarnings, tvActive, tvCompleted;
    private RiderOrderAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_rider_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvWelcome = view.findViewById(R.id.tv_rider_welcome);
        tvEarnings = view.findViewById(R.id.tv_rider_earnings);
        tvActive = view.findViewById(R.id.tv_active_deliveries);
        tvCompleted = view.findViewById(R.id.tv_completed_deliveries);

        RecyclerView rv = view.findViewById(R.id.rv_dashboard_assigned);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new RiderOrderAdapter(new ArrayList<>(), order -> {
            Intent i = new Intent(requireContext(), RiderDeliveryDetailActivity.class);
            i.putExtra(RiderDeliveryDetailActivity.EXTRA_ORDER_ID, order.getOrderId());
            startActivity(i);
        });
        rv.setAdapter(adapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        Rider rider = RepositoryProvider.auth(requireContext()).getCurrentRider();
        if (rider == null) {
            rider = RepositoryProvider.riders(requireContext()).getRiderById("rider_1");
        }
        if (rider == null) return;

        tvWelcome.setText("Assalam-o-Alaikum, " + rider.getName());
        tvEarnings.setText(CurrencyUtil.formatPkr(rider.getTotalEarnings()));
        tvCompleted.setText(String.valueOf(rider.getTotalDeliveries()));

        List<Order> mine = RepositoryProvider.orders(requireContext()).getOrdersByRider(rider.getId());
        List<Order> active = new ArrayList<>();
        for (Order o : mine) {
            if (!OrderStatus.isCompletedOrCancelled(o.getOrderStatus())) {
                active.add(o);
            }
        }
        tvActive.setText(String.valueOf(active.size()));
        adapter.updateOrders(active);
    }
}
