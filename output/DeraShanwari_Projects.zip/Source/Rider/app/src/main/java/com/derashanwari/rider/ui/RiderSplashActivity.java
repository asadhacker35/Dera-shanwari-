package com.derashanwari.rider.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.derashanwari.rider.MainActivity;
import com.derashanwari.rider.R;
import com.derashanwari.rider.repository.RepositoryProvider;

public class RiderSplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_splash);
        RepositoryProvider.init(this);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing()) return;
            boolean loggedIn = RepositoryProvider.auth(this).getCurrentRider() != null;
            startActivity(new Intent(this, loggedIn ? MainActivity.class : RiderLoginActivity.class));
            finish();
        }, 800);
    }
}
