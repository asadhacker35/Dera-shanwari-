package com.derashanwari.rider.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.derashanwari.rider.R;
import com.derashanwari.rider.model.Order;
import com.derashanwari.rider.model.OrderItem;
import com.derashanwari.rider.model.OrderStatus;
import com.derashanwari.rider.repository.RepositoryProvider;
import com.derashanwari.rider.util.CurrencyUtil;
import com.derashanwari.rider.util.ValidationUtil;
import com.derashanwari.rider.util.WhatsAppHelper;
import com.google.android.material.appbar.MaterialToolbar;

public class RiderDeliveryDetailActivity extends AppCompatActivity {
    public static final String EXTRA_ORDER_ID = "extra_order_id";

    private Order order;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_delivery_detail);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        String orderId = getIntent().getStringExtra(EXTRA_ORDER_ID);
        order = RepositoryProvider.orders(this).getOrderById(orderId);
        if (order == null) {
            Toast.makeText(this, "Order not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        bindOrder();

        findViewById(R.id.btn_call_customer).setOnClickListener(v -> {
            Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + order.getCustomerPhone()));
            startActivity(dial);
        });

        findViewById(R.id.btn_whatsapp_customer).setOnClickListener(v -> {
            String msg = "Assalam-o-Alaikum " + order.getCustomerName()
                    + ", I am your Dera Shanwari rider for order " + order.getOrderId() + ".";
            WhatsAppHelper.openWhatsAppWithMessage(this, order.getCustomerPhone(), msg);
        });

        findViewById(R.id.btn_status_picked_up).setOnClickListener(v -> updateStatus(OrderStatus.PICKED_UP));
        findViewById(R.id.btn_status_out).setOnClickListener(v -> updateStatus(OrderStatus.OUT_FOR_DELIVERY));
        findViewById(R.id.btn_status_delivered).setOnClickListener(v -> updateStatus(OrderStatus.DELIVERED));
    }

    private void updateStatus(String status) {
        RepositoryProvider.orders(this).updateOrderStatus(order.getOrderId(), status);
        order = RepositoryProvider.orders(this).getOrderById(order.getOrderId());
        bindOrder();
        Toast.makeText(this, "Status updated: " + status, Toast.LENGTH_SHORT).show();
    }

    private void bindOrder() {
        ((TextView) findViewById(R.id.tv_delivery_header)).setText(
                order.getOrderId() + " • " + order.getOrderStatus());
        ((TextView) findViewById(R.id.tv_delivery_customer)).setText(
                "Customer: " + order.getCustomerName()
                        + "\nPhone: " + order.getCustomerPhone()
                        + "\nAddress: " + order.getDeliveryAddress()
                        + "\nPayment: " + order.getPaymentMethod() + " (" + order.getPaymentStatus() + ")"
                        + (ValidationUtil.isNonEmpty(order.getNotes()) ? "\nInstructions: " + order.getNotes() : ""));

        StringBuilder sb = new StringBuilder();
        for (OrderItem item : order.getItems()) {
            sb.append(item.getQuantity()).append("x ").append(item.getProductName()).append("\n");
        }
        sb.append("\nTotal Amount: ").append(CurrencyUtil.formatPkr(order.getTotalAmount()));
        ((TextView) findViewById(R.id.tv_delivery_items)).setText(sb.toString());
    }
}
