package com.derashanwari.rider.repository;

import com.derashanwari.rider.model.ChatMessage;

import java.util.List;

public interface ChatRepository {
    List<ChatMessage> getMessagesForOrder(String orderId);
    void sendMessage(ChatMessage message);
}
