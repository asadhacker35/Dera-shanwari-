package com.derashanwari.rider.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.derashanwari.rider.MainActivity;
import com.derashanwari.rider.R;
import com.derashanwari.rider.model.Rider;
import com.derashanwari.rider.repository.AuthRepository;
import com.derashanwari.rider.repository.RepositoryProvider;

public class RiderLoginActivity extends AppCompatActivity {
    private EditText etPhone, etPin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rider_login);
        etPhone = findViewById(R.id.et_rider_phone);
        etPin = findViewById(R.id.et_rider_pin);

        findViewById(R.id.btn_rider_login).setOnClickListener(v -> attemptLogin());
        findViewById(R.id.btn_demo_rider_quick).setOnClickListener(v -> {
            etPhone.setText("03125556677");
            etPin.setText("1234");
            attemptLogin();
        });
    }

    private void attemptLogin() {
        String phone = etPhone.getText().toString().trim();
        String pin = etPin.getText().toString().trim();
        RepositoryProvider.auth(this).loginRider(phone, pin, new AuthRepository.AuthCallback<Rider>() {
            @Override
            public void onSuccess(Rider user) {
                Toast.makeText(RiderLoginActivity.this, "Welcome, " + user.getName(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(RiderLoginActivity.this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();
            }

            @Override
            public void onError(String message) {
                Toast.makeText(RiderLoginActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }
}
