package com.derashanwari.rider.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.derashanwari.rider.R;
import com.derashanwari.rider.model.Rider;
import com.derashanwari.rider.repository.RepositoryProvider;
import com.derashanwari.rider.ui.RiderLoginActivity;
import com.derashanwari.rider.util.CurrencyUtil;
import com.derashanwari.rider.util.ImageLoaderUtil;

public class RiderProfileFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_rider_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Rider rider = RepositoryProvider.auth(requireContext()).getCurrentRider();
        if (rider == null) {
            rider = RepositoryProvider.riders(requireContext()).getRiderById("rider_1");
        }
        if (rider != null) {
            ImageView avatar = view.findViewById(R.id.iv_rider_avatar);
            ImageLoaderUtil.loadImage(avatar, rider.getProfileImageUrl(), "ic_dera_emblem");
            ((TextView) view.findViewById(R.id.tv_profile_name)).setText(rider.getName());
            ((TextView) view.findViewById(R.id.tv_profile_phone)).setText(rider.getPhone());
            ((TextView) view.findViewById(R.id.tv_profile_vehicle)).setText(
                    rider.getVehicleInfo() + " • " + rider.getTotalDeliveries() + " deliveries ("
                            + CurrencyUtil.formatPkr(rider.getTotalEarnings()) + ")");
            ((TextView) view.findViewById(R.id.tv_profile_status)).setText(
                    rider.isActive() ? "ACCOUNT ACTIVE" : "ACCOUNT INACTIVE");
        }

        view.findViewById(R.id.btn_rider_logout).setOnClickListener(v -> {
            RepositoryProvider.auth(requireContext()).logout();
            Intent i = new Intent(requireContext(), RiderLoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        });
    }
}
