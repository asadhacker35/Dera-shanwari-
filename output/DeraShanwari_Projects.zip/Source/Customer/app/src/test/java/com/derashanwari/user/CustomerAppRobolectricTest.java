package com.derashanwari.user;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;

import com.derashanwari.user.model.Customer;
import com.derashanwari.user.model.Order;
import com.derashanwari.user.model.OrderStatus;
import com.derashanwari.user.model.Product;
import com.derashanwari.user.repository.AuthRepository;
import com.derashanwari.user.repository.RepositoryProvider;
import com.derashanwari.user.repository.demo.CartManager;
import com.derashanwari.user.ui.AuthActivity;
import com.derashanwari.user.util.WhatsAppHelper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = {35})
public class CustomerAppRobolectricTest {
    private Context context;

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
        RepositoryProvider.resetForTests();
        RepositoryProvider.init(context);
    }

    @Test
    public void appNameAndStartup_workCorrectly() {
        assertEquals("Dera Shanwari", context.getString(R.string.app_name));
        AuthActivity auth = Robolectric.buildActivity(AuthActivity.class).setup().get();
        assertNotNull(auth);
        MainActivity main = Robolectric.buildActivity(MainActivity.class).setup().get();
        assertNotNull(main);
    }

    @Test
    public void demoCustomerLoginAndOrderingFlow_succeeds() {
        AuthRepository authRepo = RepositoryProvider.auth(context);
        final boolean[] loggedIn = {false};
        authRepo.verifyCustomerOtp("03009876543", "1234", "Usman Tariq", "Hayatabad Peshawar",
                new AuthRepository.AuthCallback<Customer>() {
                    @Override public void onSuccess(Customer user) {
                        loggedIn[0] = true;
                        assertEquals("03009876543", user.getPhone());
                    }
                    @Override public void onError(String message) {}
                });
        assertTrue(loggedIn[0]);

        Product karahi = RepositoryProvider.products(context).getAllProducts().get(0);
        CartManager cart = CartManager.getInstance(context);
        cart.clear();
        cart.addProduct(karahi, 2);
        assertEquals(2, cart.getTotalItemCount());
        assertTrue(cart.getSubtotal() > 0);

        Order order = new Order();
        order.setCustomerId("cust_1");
        order.setCustomerName("Usman Tariq");
        order.setCustomerPhone("03009876543");
        order.setDeliveryAddress("Hayatabad Phase 2, Peshawar");
        order.setItems(cart.getItems());
        order.setSubtotal(cart.getSubtotal());
        order.setDeliveryFee(150);
        order.setTotalAmount(cart.getSubtotal() + 150);
        order.setPaymentMethod("Cash on Delivery");

        Order placed = RepositoryProvider.orders(context).placeOrder(order);
        assertNotNull(placed.getOrderId());
        assertEquals(OrderStatus.PENDING, placed.getOrderStatus());

        String waMsg = WhatsAppHelper.buildOrderMessage(placed, RepositoryProvider.settings(context).getRestaurantSettings());
        assertTrue(waMsg.contains("Dera Shanwari"));
        assertTrue(waMsg.contains(placed.getOrderId()));
        assertTrue(waMsg.contains(karahi.getName()));
        assertFalse(waMsg.isEmpty());
    }
}
