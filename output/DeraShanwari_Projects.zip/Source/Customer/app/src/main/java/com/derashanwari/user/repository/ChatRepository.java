package com.derashanwari.user.repository;

import com.derashanwari.user.model.ChatMessage;

import java.util.List;

public interface ChatRepository {
    List<ChatMessage> getMessagesForOrder(String orderId);
    void sendMessage(ChatMessage message);
}
