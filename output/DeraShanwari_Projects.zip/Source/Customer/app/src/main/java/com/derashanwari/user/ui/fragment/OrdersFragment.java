package com.derashanwari.user.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.derashanwari.user.R;
import com.derashanwari.user.model.Customer;
import com.derashanwari.user.model.Order;
import com.derashanwari.user.repository.RepositoryProvider;
import com.derashanwari.user.ui.OrderDetailActivity;
import com.derashanwari.user.ui.adapter.OrderAdapter;

import java.util.ArrayList;
import java.util.List;

public class OrdersFragment extends Fragment {
    private OrderAdapter adapter;
    private TextView tvEmpty;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_orders, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvEmpty = view.findViewById(R.id.tv_orders_empty);
        RecyclerView rv = view.findViewById(R.id.rv_orders);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new OrderAdapter(new ArrayList<>(), order -> {
            Intent i = new Intent(requireContext(), OrderDetailActivity.class);
            i.putExtra(OrderDetailActivity.EXTRA_ORDER_ID, order.getOrderId());
            startActivity(i);
        });
        rv.setAdapter(adapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        Customer c = RepositoryProvider.auth(requireContext()).getCurrentCustomer();
        List<Order> orders = c != null
                ? RepositoryProvider.orders(requireContext()).getOrdersByCustomer(c.getId())
                : new ArrayList<>();
        adapter.updateOrders(orders);
        tvEmpty.setVisibility(orders.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
