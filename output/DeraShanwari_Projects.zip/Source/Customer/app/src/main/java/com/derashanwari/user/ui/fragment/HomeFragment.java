package com.derashanwari.user.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.derashanwari.user.MainActivity;
import com.derashanwari.user.R;
import com.derashanwari.user.model.Category;
import com.derashanwari.user.model.Customer;
import com.derashanwari.user.model.Product;
import com.derashanwari.user.model.RestaurantSettings;
import com.derashanwari.user.repository.ProductRepository;
import com.derashanwari.user.repository.RepositoryProvider;
import com.derashanwari.user.repository.demo.CartManager;
import com.derashanwari.user.ui.ProductDetailActivity;
import com.derashanwari.user.ui.RewardsActivity;
import com.derashanwari.user.ui.adapter.BannerAdapter;
import com.derashanwari.user.ui.adapter.CategoryAdapter;
import com.derashanwari.user.ui.adapter.ProductAdapter;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    private ProductRepository productRepo;
    private ProductAdapter popularAdapter;
    private TextView tvAddressPill, tvPointsPill, tvRestaurantTitle, tvPopularHeader;
    private String selectedCategoryId = "ALL";
    private String searchQuery = "";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        productRepo = RepositoryProvider.products(requireContext());

        tvRestaurantTitle = view.findViewById(R.id.tv_restaurant_title);
        tvAddressPill = view.findViewById(R.id.tv_delivery_address_pill);
        tvPointsPill = view.findViewById(R.id.tv_points_pill);
        tvPopularHeader = view.findViewById(R.id.tv_popular_header);
        EditText etSearch = view.findViewById(R.id.et_home_search);

        tvPointsPill.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), RewardsActivity.class)));

        RecyclerView rvBanners = view.findViewById(R.id.rv_banners);
        rvBanners.setLayoutManager(new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false));
        rvBanners.setAdapter(new BannerAdapter(productRepo.getActiveBanners()));

        RecyclerView rvCategories = view.findViewById(R.id.rv_categories);
        rvCategories.setLayoutManager(new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false));
        List<Category> cats = new ArrayList<>();
        cats.add(new Category("ALL", "All", "", "ic_dera_emblem", true, 0));
        cats.addAll(productRepo.getAvailableCategories());
        CategoryAdapter categoryAdapter = new CategoryAdapter(cats, cat -> {
            selectedCategoryId = cat.getId();
            applyFilter();
        });
        rvCategories.setAdapter(categoryAdapter);

        RecyclerView rvFeatured = view.findViewById(R.id.rv_featured_products);
        rvFeatured.setLayoutManager(new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false));
        ProductAdapter.OnProductActionListener productListener = new ProductAdapter.OnProductActionListener() {
            @Override
            public void onProductClick(Product product) {
                Intent i = new Intent(requireContext(), ProductDetailActivity.class);
                i.putExtra(ProductDetailActivity.EXTRA_PRODUCT_ID, product.getId());
                startActivity(i);
            }

            @Override
            public void onQuickAddClick(Product product) {
                CartManager.getInstance(requireContext()).addProduct(product, 1);
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).refreshCartBadge();
                }
                Toast.makeText(requireContext(), product.getName() + " added to cart", Toast.LENGTH_SHORT).show();
            }
        };
        rvFeatured.setAdapter(new ProductAdapter(productRepo.getFeaturedProducts(), true, productListener));

        RecyclerView rvPopular = view.findViewById(R.id.rv_popular_products);
        rvPopular.setLayoutManager(new LinearLayoutManager(requireContext()));
        popularAdapter = new ProductAdapter(new ArrayList<>(), false, productListener);
        rvPopular.setAdapter(popularAdapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s != null ? s.toString().trim() : "";
                applyFilter();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        applyFilter();
    }

    @Override
    public void onResume() {
        super.onResume();
        RestaurantSettings settings = RepositoryProvider.settings(requireContext()).getRestaurantSettings();
        if (settings != null) {
            tvRestaurantTitle.setText(settings.getRestaurantName().toUpperCase());
        }
        Customer c = RepositoryProvider.auth(requireContext()).getCurrentCustomer();
        if (c != null) {
            tvAddressPill.setText("Deliver to: " + c.getAddress());
            tvPointsPill.setText(c.getLoyaltyPoints() + " pts");
        } else {
            tvAddressPill.setText("Deliver to: Peshawar");
            tvPointsPill.setText("0 pts");
        }
    }

    private void applyFilter() {
        List<Product> filtered;
        if (!searchQuery.isEmpty()) {
            filtered = productRepo.searchProducts(searchQuery);
            tvPopularHeader.setText("Search Results (" + filtered.size() + ")");
        } else if (!"ALL".equals(selectedCategoryId)) {
            filtered = productRepo.getProductsByCategory(selectedCategoryId);
            tvPopularHeader.setText("Category Dishes (" + filtered.size() + ")");
        } else {
            filtered = productRepo.getPopularProducts();
            tvPopularHeader.setText("Popular Dishes");
        }
        popularAdapter.updateItems(filtered);
    }
}
