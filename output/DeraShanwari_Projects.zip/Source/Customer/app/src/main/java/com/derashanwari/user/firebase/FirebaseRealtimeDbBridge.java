package com.derashanwari.user.firebase;

import android.content.Context;
import android.util.Log;

/**
 * Integration bridge for Firebase Realtime Database and Firebase Authentication.
 * Currently operates in DEMO MODE without requiring google-services.json.
 * See /Documentation/FIREBASE_AND_IMAGEKIT_GUIDE.md for live connection steps.
 */
public class FirebaseRealtimeDbBridge {
    private static final String TAG = "DeraFirebaseBridge";
    private final boolean firebaseAvailable;

    public FirebaseRealtimeDbBridge(Context context) {
        this.firebaseAvailable = detectGoogleServicesConfig(context);
        Log.i(TAG, "Firebase bridge initialized. DemoMode=" + FirebaseConfig.DEMO_MODE
                + ", GoogleServicesConfigured=" + firebaseAvailable);
    }

    public boolean isLiveFirebaseReady() {
        return !FirebaseConfig.DEMO_MODE && firebaseAvailable;
    }

    public String getPath(String rootNode, String childId) {
        if (childId == null || childId.trim().isEmpty()) {
            return "/" + rootNode;
        }
        return "/" + rootNode + "/" + childId.trim();
    }

    private boolean detectGoogleServicesConfig(Context context) {
        try {
            int resId = context.getResources().getIdentifier(
                    "google_app_id", "string", context.getPackageName());
            return resId != 0;
        } catch (Exception e) {
            return false;
        }
    }
}
