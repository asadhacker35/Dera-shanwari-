package com.derashanwari.user.ui;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.derashanwari.user.R;
import com.derashanwari.user.model.ChatMessage;
import com.derashanwari.user.model.Customer;
import com.derashanwari.user.model.Order;
import com.derashanwari.user.model.OrderItem;
import com.derashanwari.user.model.OrderStatus;
import com.derashanwari.user.model.RestaurantSettings;
import com.derashanwari.user.repository.RepositoryProvider;
import com.derashanwari.user.util.CurrencyUtil;
import com.derashanwari.user.util.ValidationUtil;
import com.derashanwari.user.util.WhatsAppHelper;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.List;

public class OrderDetailActivity extends AppCompatActivity {
    public static final String EXTRA_ORDER_ID = "extra_order_id";

    private Order order;
    private TextView tvChatLog;
    private EditText etChatMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        String orderId = getIntent().getStringExtra(EXTRA_ORDER_ID);
        order = RepositoryProvider.orders(this).getOrderById(orderId);
        if (order == null) {
            Toast.makeText(this, "Order not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        bindOrderDetails();

        findViewById(R.id.btn_send_whatsapp).setOnClickListener(v -> {
            RestaurantSettings settings = RepositoryProvider.settings(this).getRestaurantSettings();
            String msg = WhatsAppHelper.buildOrderMessage(order, settings);
            String waNumber = settings != null ? settings.getWhatsappNumber() : "923001112233";
            WhatsAppHelper.openWhatsAppWithMessage(this, waNumber, msg);
        });

        tvChatLog = findViewById(R.id.tv_chat_log);
        etChatMessage = findViewById(R.id.et_chat_message);
        findViewById(R.id.btn_send_chat).setOnClickListener(v -> sendChat());
        refreshChat();
    }

    private void bindOrderDetails() {
        ((TextView) findViewById(R.id.tv_order_id)).setText("Order " + order.getOrderId());
        ((TextView) findViewById(R.id.tv_order_status_big)).setText(order.getOrderStatus());
        String riderText = ValidationUtil.isNonEmpty(order.getRiderName())
                ? " • Rider: " + order.getRiderName() : "";
        ((TextView) findViewById(R.id.tv_order_meta)).setText(
                order.getPaymentMethod() + " (" + order.getPaymentStatus() + ")" + riderText
                        + "\nDeliver to: " + order.getDeliveryAddress());

        LinearLayout stepsLayout = findViewById(R.id.layout_tracking_steps);
        stepsLayout.removeAllViews();
        List<String> steps = OrderStatus.customerTrackingSteps();
        int currentIdx = steps.indexOf(order.getOrderStatus());
        if (OrderStatus.PICKED_UP.equalsIgnoreCase(order.getOrderStatus())) {
            currentIdx = steps.indexOf(OrderStatus.ASSIGNED);
        }
        for (int i = 0; i < steps.size(); i++) {
            TextView tv = new TextView(this);
            boolean reached = (currentIdx >= i) && !OrderStatus.CANCELLED.equalsIgnoreCase(order.getOrderStatus());
            tv.setText((reached ? "● " : "○ ") + steps.get(i));
            tv.setTextSize(14f);
            tv.setPadding(8, 8, 8, 8);
            tv.setTextColor(ContextCompat.getColor(this,
                    reached ? R.color.brand_orange_dark : R.color.text_secondary));
            stepsLayout.addView(tv);
        }

        StringBuilder itemsText = new StringBuilder();
        for (OrderItem item : order.getItems()) {
            itemsText.append(item.getQuantity()).append("x ")
                    .append(item.getProductName()).append(" — ")
                    .append(CurrencyUtil.formatPkr(item.getLineTotal())).append("\n");
        }
        if (ValidationUtil.isNonEmpty(order.getNotes())) {
            itemsText.append("\nNotes: ").append(order.getNotes());
        }
        ((TextView) findViewById(R.id.tv_order_items_summary)).setText(itemsText.toString().trim());
        ((TextView) findViewById(R.id.tv_order_totals)).setText(
                "Subtotal: " + CurrencyUtil.formatPkr(order.getSubtotal())
                        + "  |  Delivery: " + CurrencyUtil.formatPkr(order.getDeliveryFee())
                        + "\nGrand Total: " + CurrencyUtil.formatPkr(order.getTotalAmount()));
    }

    private void refreshChat() {
        List<ChatMessage> msgs = RepositoryProvider.chat(this).getMessagesForOrder(order.getOrderId());
        if (msgs.isEmpty()) {
            tvChatLog.setText("No messages yet. Ask kitchen or rider anything about your order.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (ChatMessage m : msgs) {
            sb.append("[").append(m.getSenderRole()).append("] ")
                    .append(m.getSenderName()).append(": ")
                    .append(m.getMessage()).append("\n");
        }
        tvChatLog.setText(sb.toString().trim());
    }

    private void sendChat() {
        String text = etChatMessage.getText().toString().trim();
        if (!ValidationUtil.isNonEmpty(text)) return;
        Customer c = RepositoryProvider.auth(this).getCurrentCustomer();
        ChatMessage msg = new ChatMessage(
                "",
                order.getOrderId(),
                c != null ? c.getId() : "guest",
                "CUSTOMER",
                c != null ? c.getName() : order.getCustomerName(),
                text,
                System.currentTimeMillis()
        );
        RepositoryProvider.chat(this).sendMessage(msg);
        etChatMessage.setText("");
        refreshChat();
    }
}
