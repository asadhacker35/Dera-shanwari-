package com.derashanwari.user.firebase;

import android.util.Log;

/**
 * Firebase Cloud Messaging (FCM) notification contract.
 * Ready to connect to FirebaseMessagingService when Firebase is provisioned.
 */
public final class FcmNotificationBridge {
    private static final String TAG = "DeraFcmBridge";

    private FcmNotificationBridge() {}

    public static void notifyOrderStatusChanged(String orderId, String newStatus, String customerId) {
        Log.d(TAG, "[DEMO FCM] Order " + orderId + " status -> " + newStatus
                + " (target topic: " + FirebaseConfig.TOPIC_CUSTOMER_PREFIX + customerId + ")");
    }

    public static void notifyRiderAssigned(String orderId, String riderId) {
        Log.d(TAG, "[DEMO FCM] Rider " + riderId + " assigned to order " + orderId
                + " (target topic: " + FirebaseConfig.TOPIC_RIDER_PREFIX + riderId + ")");
    }

    public static void notifyAdminNewOrder(String orderId, double totalAmount) {
        Log.d(TAG, "[DEMO FCM] New order " + orderId + " Rs." + totalAmount
                + " (target topic: " + FirebaseConfig.TOPIC_ADMIN_NEW_ORDERS + ")");
    }
}
