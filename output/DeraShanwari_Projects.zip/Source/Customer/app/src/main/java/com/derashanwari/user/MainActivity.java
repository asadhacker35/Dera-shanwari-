package com.derashanwari.user;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.derashanwari.user.repository.RepositoryProvider;
import com.derashanwari.user.repository.demo.CartManager;
import com.derashanwari.user.ui.fragment.AccountFragment;
import com.derashanwari.user.ui.fragment.CartFragment;
import com.derashanwari.user.ui.fragment.HomeFragment;
import com.derashanwari.user.ui.fragment.MenuFragment;
import com.derashanwari.user.ui.fragment.OrdersFragment;
import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RepositoryProvider.init(this);

        bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                loadFragment(new HomeFragment());
                return true;
            } else if (id == R.id.nav_menu) {
                loadFragment(new MenuFragment());
                return true;
            } else if (id == R.id.nav_cart) {
                loadFragment(new CartFragment());
                return true;
            } else if (id == R.id.nav_orders) {
                loadFragment(new OrdersFragment());
                return true;
            } else if (id == R.id.nav_account) {
                loadFragment(new AccountFragment());
                return true;
            }
            return false;
        });

        if (savedInstanceState == null) {
            bottomNav.setSelectedItemId(R.id.nav_home);
        }
        refreshCartBadge();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshCartBadge();
    }

    public void openMenuTab() {
        if (bottomNav != null) bottomNav.setSelectedItemId(R.id.nav_menu);
    }

    public void openOrdersTab() {
        if (bottomNav != null) bottomNav.setSelectedItemId(R.id.nav_orders);
    }

    public void refreshCartBadge() {
        if (bottomNav == null) return;
        int count = CartManager.getInstance(this).getTotalItemCount();
        BadgeDrawable badge = bottomNav.getOrCreateBadge(R.id.nav_cart);
        badge.setVisible(count > 0);
        badge.setNumber(count);
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
