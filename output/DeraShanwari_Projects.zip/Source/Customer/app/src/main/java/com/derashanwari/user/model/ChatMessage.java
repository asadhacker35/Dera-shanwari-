package com.derashanwari.user.model;

import java.io.Serializable;

public class ChatMessage implements Serializable {
    private String id;
    private String orderId;
    private String senderId;
    private String senderRole; // "CUSTOMER", "ADMIN", "RIDER"
    private String senderName;
    private String message;
    private long timestamp;

    public ChatMessage() {}

    public ChatMessage(String id, String orderId, String senderId, String senderRole,
                       String senderName, String message, long timestamp) {
        this.id = id;
        this.orderId = orderId;
        this.senderId = senderId;
        this.senderRole = senderRole;
        this.senderName = senderName;
        this.message = message;
        this.timestamp = timestamp;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getSenderId() { return senderId; }
    public void setSenderId(String senderId) { this.senderId = senderId; }

    public String getSenderRole() { return senderRole; }
    public void setSenderRole(String senderRole) { this.senderRole = senderRole; }

    public String getSenderName() { return senderName; }
    public void setSenderName(String senderName) { this.senderName = senderName; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
}
