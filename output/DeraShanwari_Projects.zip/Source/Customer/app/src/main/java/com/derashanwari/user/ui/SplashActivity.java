package com.derashanwari.user.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.derashanwari.user.MainActivity;
import com.derashanwari.user.R;
import com.derashanwari.user.repository.RepositoryProvider;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        RepositoryProvider.init(this);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing()) return;
            boolean loggedIn = RepositoryProvider.auth(this).getCurrentCustomer() != null;
            Intent intent = new Intent(this, loggedIn ? MainActivity.class : AuthActivity.class);
            startActivity(intent);
            finish();
        }, 900);
    }
}
