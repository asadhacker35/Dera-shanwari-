package com.derashanwari.user.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.derashanwari.user.MainActivity;
import com.derashanwari.user.R;
import com.derashanwari.user.model.Customer;
import com.derashanwari.user.repository.AuthRepository;
import com.derashanwari.user.repository.RepositoryProvider;
import com.google.android.material.button.MaterialButton;

public class AuthActivity extends AppCompatActivity {
    private EditText etPhone, etOtp, etName, etAddress;
    private LinearLayout layoutOtpSection;
    private TextView tvBanner;
    private AuthRepository authRepo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        authRepo = RepositoryProvider.auth(this);

        etPhone = findViewById(R.id.et_phone);
        etOtp = findViewById(R.id.et_otp);
        etName = findViewById(R.id.et_name);
        etAddress = findViewById(R.id.et_address);
        layoutOtpSection = findViewById(R.id.layout_otp_section);
        tvBanner = findViewById(R.id.tv_demo_otp_banner);

        MaterialButton btnSendOtp = findViewById(R.id.btn_send_otp);
        MaterialButton btnVerifyOtp = findViewById(R.id.btn_verify_otp);
        MaterialButton btnQuickDemo = findViewById(R.id.btn_demo_quick_login);

        btnSendOtp.setOnClickListener(v -> sendOtp());
        btnVerifyOtp.setOnClickListener(v -> verifyOtp());
        btnQuickDemo.setOnClickListener(v -> performQuickDemoLogin());
    }

    private void sendOtp() {
        String phone = etPhone.getText().toString().trim();
        authRepo.sendCustomerOtp(phone, new AuthRepository.AuthCallback<String>() {
            @Override
            public void onSuccess(String demoOtp) {
                layoutOtpSection.setVisibility(View.VISIBLE);
                tvBanner.setText("Demo OTP generated: " + demoOtp + " (Enter " + demoOtp + " below to continue)");
                Customer existing = RepositoryProvider.customers(AuthActivity.this).getCustomerByPhone(phone);
                if (existing != null) {
                    etName.setText(existing.getName());
                    etAddress.setText(existing.getAddress());
                }
                Toast.makeText(AuthActivity.this, "Demo OTP: " + demoOtp, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onError(String message) {
                etPhone.setError(message);
                Toast.makeText(AuthActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void verifyOtp() {
        String phone = etPhone.getText().toString().trim();
        String otp = etOtp.getText().toString().trim();
        String name = etName.getText().toString().trim();
        String address = etAddress.getText().toString().trim();

        authRepo.verifyCustomerOtp(phone, otp, name, address, new AuthRepository.AuthCallback<Customer>() {
            @Override
            public void onSuccess(Customer user) {
                Toast.makeText(AuthActivity.this, "Welcome, " + user.getName(), Toast.LENGTH_SHORT).show();
                openMain();
            }

            @Override
            public void onError(String message) {
                Toast.makeText(AuthActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void performQuickDemoLogin() {
        etPhone.setText("03009876543");
        layoutOtpSection.setVisibility(View.VISIBLE);
        etOtp.setText("1234");
        etName.setText("Usman Tariq");
        etAddress.setText("House 14, Street 6, Hayatabad Phase 2, Peshawar");
        verifyOtp();
    }

    private void openMain() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
