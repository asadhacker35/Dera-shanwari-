package com.derashanwari.user.config;

/**
 * Centralized ImageKit.io CDN configuration for Dera Shanwari.
 * Never store private ImageKit API keys or signature secrets in client apps.
 * Only public delivery endpoint URLs are stored in database records.
 */
public final class ImageKitConfig {
    public static final String BASE_CDN_ENDPOINT = "https://ik.imagekit.io/derashanwari/";
    public static final String FOLDER_PRODUCTS = "products/";
    public static final String FOLDER_CATEGORIES = "categories/";
    public static final String FOLDER_BANNERS = "banners/";
    public static final String FOLDER_BRAND = "brand/";

    private ImageKitConfig() {}

    public static String buildTransformedUrl(String rawUrl, int widthPx, int heightPx) {
        if (rawUrl == null || rawUrl.trim().isEmpty()) {
            return "";
        }
        String trimmed = rawUrl.trim();
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
            return BASE_CDN_ENDPOINT + trimmed;
        }
        if (trimmed.contains("ik.imagekit.io") && !trimmed.contains("?tr=")) {
            return trimmed + "?tr=w-" + widthPx + ",h-" + heightPx + ",fo-auto,q-80";
        }
        return trimmed;
    }

    public static boolean isValidImageUrl(String url) {
        if (url == null || url.trim().isEmpty()) return false;
        String lower = url.trim().toLowerCase();
        return lower.startsWith("https://") || lower.startsWith("http://") || lower.startsWith("local://");
    }
}
