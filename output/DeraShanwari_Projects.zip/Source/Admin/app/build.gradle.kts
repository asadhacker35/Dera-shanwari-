plugins {
    alias(libs.plugins.android.application)
    // Enable once google-services.json is placed inside app/:
    // id("com.google.gms.google-services")
}

android {
    namespace = "com.derashanwari.admin"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.derashanwari.admin"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
        }
    }
}

dependencies {
    implementation(libs.androidx.appcompat)
    implementation(libs.google.material)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.recyclerview)
    implementation(libs.androidx.cardview)
    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.gson)
    implementation(libs.glide)

    // Firebase integration dependencies (uncomment when adding google-services.json):
    // implementation(platform("com.google.firebase:firebase-bom:33.10.0"))
    // implementation("com.google.firebase:firebase-auth")
    // implementation("com.google.firebase:firebase-database")
    // implementation("com.google.firebase:firebase-messaging")

    testImplementation(libs.junit)
    testImplementation(libs.androidx.core)
    testImplementation(libs.androidx.junit)
    testImplementation(libs.robolectric)
}
