package com.derashanwari.admin.repository.demo;

import com.derashanwari.admin.model.ChatMessage;
import com.derashanwari.admin.repository.ChatRepository;

import java.util.ArrayList;
import java.util.List;

public class DemoChatRepository implements ChatRepository {
    private final DemoDatabaseManager db;

    public DemoChatRepository(DemoDatabaseManager db) {
        this.db = db;
    }

    @Override
    public List<ChatMessage> getMessagesForOrder(String orderId) {
        List<ChatMessage> result = new ArrayList<>();
        for (ChatMessage msg : db.getState().chats) {
            if (orderId != null && orderId.equals(msg.getOrderId())) {
                result.add(msg);
            }
        }
        return result;
    }

    @Override
    public void sendMessage(ChatMessage message) {
        if (message.getId() == null || message.getId().trim().isEmpty()) {
            message.setId("msg_" + System.currentTimeMillis());
        }
        if (message.getTimestamp() <= 0) {
            message.setTimestamp(System.currentTimeMillis());
        }
        db.getState().chats.add(message);
        db.save();
    }
}
