package com.derashanwari.admin.repository.demo;

import com.derashanwari.admin.firebase.FcmNotificationBridge;
import com.derashanwari.admin.model.Customer;
import com.derashanwari.admin.model.Order;
import com.derashanwari.admin.model.OrderStatus;
import com.derashanwari.admin.model.Payment;
import com.derashanwari.admin.model.PaymentMethodConfig;
import com.derashanwari.admin.model.RestaurantSettings;
import com.derashanwari.admin.model.Reward;
import com.derashanwari.admin.model.Rider;
import com.derashanwari.admin.repository.OrderRepository;

import java.util.ArrayList;
import java.util.List;

public class DemoOrderRepository implements OrderRepository {
    private final DemoDatabaseManager db;

    public DemoOrderRepository(DemoDatabaseManager db) {
        this.db = db;
    }

    @Override
    public List<Order> getAllOrders() {
        return new ArrayList<>(db.getState().orders);
    }

    @Override
    public List<Order> getOrdersByCustomer(String customerId) {
        List<Order> result = new ArrayList<>();
        for (Order o : db.getState().orders) {
            if (customerId != null && customerId.equals(o.getCustomerId())) {
                result.add(o);
            }
        }
        return result;
    }

    @Override
    public List<Order> getOrdersByRider(String riderId) {
        List<Order> result = new ArrayList<>();
        for (Order o : db.getState().orders) {
            if (riderId != null && riderId.equals(o.getRiderId())) {
                result.add(o);
            }
        }
        return result;
    }

    @Override
    public List<Order> getOrdersByStatus(String status) {
        if (status == null || "ALL".equalsIgnoreCase(status)) {
            return getAllOrders();
        }
        List<Order> result = new ArrayList<>();
        for (Order o : db.getState().orders) {
            if (status.equalsIgnoreCase(o.getOrderStatus())) {
                result.add(o);
            }
        }
        return result;
    }

    @Override
    public Order getOrderById(String orderId) {
        for (Order o : db.getState().orders) {
            if (o.getOrderId().equals(orderId)) return o;
        }
        return null;
    }

    @Override
    public Order placeOrder(Order order) {
        DemoDatabaseManager.DemoState state = db.getState();
        long now = System.currentTimeMillis();
        String id = "ORD-" + state.nextOrderSeq++;
        order.setOrderId(id);
        order.setOrderStatus(OrderStatus.PENDING);
        order.setCreatedAt(now);
        order.setUpdatedAt(now);

        if (PaymentMethodConfig.METHOD_COD.equalsIgnoreCase(order.getPaymentMethod())) {
            order.setPaymentStatus("Pending");
        } else {
            order.setPaymentStatus("Pending Verification");
        }

        RestaurantSettings settings = state.settings;
        int rate = settings != null && settings.getPointsPerHundredRs() > 0
                ? settings.getPointsPerHundredRs() : 10;
        int pts = (int) ((order.getTotalAmount() / 100.0) * rate);
        order.setPointsEarned(Math.max(10, pts));

        state.orders.add(0, order);

        String acctTitle = order.getPaymentMethod();
        String acctNum = "-";
        for (PaymentMethodConfig pm : state.paymentMethods) {
            if (pm.getDisplayName().equalsIgnoreCase(order.getPaymentMethod())) {
                acctTitle = pm.getAccountTitle();
                acctNum = pm.getAccountNumber();
                break;
            }
        }
        state.payments.add(0, new Payment(
                "pay_" + now, id, order.getPaymentMethod(),
                acctTitle, acctNum, order.getTotalAmount(),
                order.getPaymentStatus(), now
        ));

        db.save();
        FcmNotificationBridge.notifyAdminNewOrder(id, order.getTotalAmount());
        return order;
    }

    @Override
    public boolean updateOrderStatus(String orderId, String newStatus) {
        Order target = getOrderById(orderId);
        if (target == null) return false;

        String oldStatus = target.getOrderStatus();
        target.setOrderStatus(newStatus);
        target.setUpdatedAt(System.currentTimeMillis());

        if (OrderStatus.DELIVERED.equalsIgnoreCase(newStatus)
                && !OrderStatus.DELIVERED.equalsIgnoreCase(oldStatus)) {
            target.setPaymentStatus("Paid");
            for (Payment p : db.getState().payments) {
                if (p.getOrderId().equals(orderId)) {
                    p.setStatus("Paid");
                }
            }
            if (target.getRiderId() != null) {
                for (Rider r : db.getState().riders) {
                    if (r.getId().equals(target.getRiderId())) {
                        r.setTotalDeliveries(r.getTotalDeliveries() + 1);
                        r.setTotalEarnings(r.getTotalEarnings() + Math.max(150.0, target.getDeliveryFee()));
                        break;
                    }
                }
            }
            if (target.getCustomerId() != null && target.getPointsEarned() > 0) {
                for (Customer c : db.getState().customers) {
                    if (c.getId().equals(target.getCustomerId())) {
                        c.setLoyaltyPoints(c.getLoyaltyPoints() + target.getPointsEarned());
                        db.getState().rewards.add(0, new Reward(
                                "rew_" + System.currentTimeMillis(),
                                c.getId(),
                                "Order " + orderId + " Delivered",
                                "Earned loyalty points for completed order",
                                target.getPointsEarned(),
                                "EARNED",
                                false,
                                0,
                                orderId,
                                System.currentTimeMillis()
                        ));
                        break;
                    }
                }
            }
        }

        db.save();
        FcmNotificationBridge.notifyOrderStatusChanged(orderId, newStatus, target.getCustomerId());
        return true;
    }

    @Override
    public boolean assignRider(String orderId, String riderId, String riderName) {
        Order target = getOrderById(orderId);
        if (target == null) return false;
        target.setRiderId(riderId);
        target.setRiderName(riderName);
        if (!OrderStatus.OUT_FOR_DELIVERY.equalsIgnoreCase(target.getOrderStatus())
                && !OrderStatus.DELIVERED.equalsIgnoreCase(target.getOrderStatus())) {
            target.setOrderStatus(OrderStatus.ASSIGNED);
        }
        target.setUpdatedAt(System.currentTimeMillis());
        db.save();
        FcmNotificationBridge.notifyRiderAssigned(orderId, riderId);
        return true;
    }

    @Override
    public List<Payment> getAllPayments() {
        return new ArrayList<>(db.getState().payments);
    }

    @Override
    public void recordPayment(Payment payment) {
        db.getState().payments.add(0, payment);
        db.save();
    }

    @Override
    public boolean updatePaymentStatus(String paymentId, String status) {
        for (Payment p : db.getState().payments) {
            if (p.getId().equals(paymentId)) {
                p.setStatus(status);
                Order o = getOrderById(p.getOrderId());
                if (o != null) o.setPaymentStatus(status);
                db.save();
                return true;
            }
        }
        return false;
    }
}
