package com.derashanwari.admin.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.derashanwari.admin.R;
import com.derashanwari.admin.model.Order;
import com.derashanwari.admin.model.OrderStatus;
import com.derashanwari.admin.repository.RepositoryProvider;
import com.derashanwari.admin.ui.AdminOrderDetailActivity;
import com.derashanwari.admin.ui.adapter.AdminOrderAdapter;

import java.util.ArrayList;
import java.util.List;

public class AdminOrdersFragment extends Fragment {
    private AdminOrderAdapter adapter;
    private String selectedFilter = "ALL";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_admin_orders, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Spinner sp = view.findViewById(R.id.spinner_filter_status);
        List<String> filters = new ArrayList<>();
        filters.add("ALL");
        filters.addAll(OrderStatus.allAdminStatuses());
        sp.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, filters));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                selectedFilter = filters.get(position);
                refresh();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        RecyclerView rv = view.findViewById(R.id.rv_admin_orders);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new AdminOrderAdapter(new ArrayList<>(), order -> {
            Intent i = new Intent(requireContext(), AdminOrderDetailActivity.class);
            i.putExtra(AdminOrderDetailActivity.EXTRA_ORDER_ID, order.getOrderId());
            startActivity(i);
        });
        rv.setAdapter(adapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        List<Order> list = RepositoryProvider.orders(requireContext()).getOrdersByStatus(selectedFilter);
        adapter.updateOrders(list);
    }
}
