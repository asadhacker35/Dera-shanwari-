package com.derashanwari.admin.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.derashanwari.admin.R;
import com.derashanwari.admin.model.Order;
import com.derashanwari.admin.model.OrderStatus;
import com.derashanwari.admin.model.Payment;
import com.derashanwari.admin.model.PaymentMethodConfig;
import com.derashanwari.admin.model.RestaurantSettings;
import com.derashanwari.admin.repository.RepositoryProvider;
import com.derashanwari.admin.repository.demo.DemoDatabaseManager;
import com.derashanwari.admin.ui.AdminLoginActivity;
import com.derashanwari.admin.util.CurrencyUtil;
import com.derashanwari.admin.util.ValidationUtil;
import com.google.android.material.button.MaterialButton;

import java.util.List;

public class AdminMoreFragment extends Fragment {
    private View secPayments, secReports, secSettings;
    private MaterialButton btnPay, btnRep, btnSet;
    private LinearLayout containerMethods, containerRecords;
    private TextView tvReports;
    private EditText etName, etLogo, etPhone, etWa, etAddr, etOpen, etClose, etDeliv, etMin;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_admin_more, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        secPayments = view.findViewById(R.id.section_payments);
        secReports = view.findViewById(R.id.section_reports);
        secSettings = view.findViewById(R.id.section_settings);

        btnPay = view.findViewById(R.id.btn_more_payments);
        btnRep = view.findViewById(R.id.btn_more_reports);
        btnSet = view.findViewById(R.id.btn_more_settings);

        containerMethods = view.findViewById(R.id.container_payment_methods);
        containerRecords = view.findViewById(R.id.container_payment_records);
        tvReports = view.findViewById(R.id.tv_reports_summary);

        etName = view.findViewById(R.id.et_set_name);
        etLogo = view.findViewById(R.id.et_set_logo);
        etPhone = view.findViewById(R.id.et_set_phone);
        etWa = view.findViewById(R.id.et_set_whatsapp);
        etAddr = view.findViewById(R.id.et_set_address);
        etOpen = view.findViewById(R.id.et_set_open);
        etClose = view.findViewById(R.id.et_set_close);
        etDeliv = view.findViewById(R.id.et_set_delivery);
        etMin = view.findViewById(R.id.et_set_min_order);

        btnPay.setOnClickListener(v -> showSection(0));
        btnRep.setOnClickListener(v -> showSection(1));
        btnSet.setOnClickListener(v -> showSection(2));

        view.findViewById(R.id.btn_save_settings).setOnClickListener(v -> saveSettings());
        view.findViewById(R.id.btn_reset_demo).setOnClickListener(v -> {
            DemoDatabaseManager.getInstance(requireContext()).resetDemoData();
            Toast.makeText(requireContext(), "Demo data reset to defaults", Toast.LENGTH_SHORT).show();
            showSection(0);
        });
        view.findViewById(R.id.btn_admin_logout).setOnClickListener(v -> {
            RepositoryProvider.auth(requireContext()).logout();
            Intent i = new Intent(requireContext(), AdminLoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        });

        showSection(0);
    }

    private void showSection(int index) {
        int active = ContextCompat.getColor(requireContext(), R.color.admin_orange);
        int idle = ContextCompat.getColor(requireContext(), R.color.admin_surface_elevated);
        btnPay.setBackgroundColor(index == 0 ? active : idle);
        btnRep.setBackgroundColor(index == 1 ? active : idle);
        btnSet.setBackgroundColor(index == 2 ? active : idle);

        secPayments.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        secReports.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        secSettings.setVisibility(index == 2 ? View.VISIBLE : View.GONE);

        if (index == 0) bindPayments();
        else if (index == 1) bindReports();
        else bindSettings();
    }

    private void bindPayments() {
        containerMethods.removeAllViews();
        for (PaymentMethodConfig pm : RepositoryProvider.settings(requireContext()).getPaymentMethods()) {
            LinearLayout card = new LinearLayout(requireContext());
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.admin_surface));
            card.setPadding(24, 20, 24, 20);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 16);
            card.setLayoutParams(lp);

            SwitchCompat sw = new SwitchCompat(requireContext());
            sw.setText(pm.getDisplayName());
            sw.setTextColor(ContextCompat.getColor(requireContext(), R.color.admin_yellow));
            sw.setChecked(pm.isEnabled());
            card.addView(sw);

            EditText etTitle = new EditText(requireContext());
            etTitle.setHint("Account Title");
            etTitle.setText(pm.getAccountTitle());
            etTitle.setTextColor(ContextCompat.getColor(requireContext(), R.color.admin_white));
            card.addView(etTitle);

            EditText etNum = new EditText(requireContext());
            etNum.setHint("Account Number");
            etNum.setText(pm.getAccountNumber());
            etNum.setTextColor(ContextCompat.getColor(requireContext(), R.color.admin_white));
            card.addView(etNum);

            MaterialButton btnSave = new MaterialButton(requireContext());
            btnSave.setText("Save " + pm.getDisplayName());
            btnSave.setOnClickListener(v -> {
                pm.setEnabled(sw.isChecked());
                pm.setAccountTitle(etTitle.getText().toString().trim());
                pm.setAccountNumber(etNum.getText().toString().trim());
                RepositoryProvider.settings(requireContext()).savePaymentMethod(pm);
                Toast.makeText(requireContext(), pm.getDisplayName() + " updated", Toast.LENGTH_SHORT).show();
            });
            card.addView(btnSave);
            containerMethods.addView(card);
        }

        containerRecords.removeAllViews();
        for (Payment p : RepositoryProvider.orders(requireContext()).getAllPayments()) {
            TextView tv = new TextView(requireContext());
            tv.setText(p.getOrderId() + " • " + p.getMethod() + " • "
                    + CurrencyUtil.formatPkr(p.getAmount()) + " [" + p.getStatus() + "] (Tap to mark Paid)");
            tv.setTextColor(ContextCompat.getColor(requireContext(), R.color.admin_white));
            tv.setPadding(16, 16, 16, 16);
            tv.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.admin_surface));
            tv.setOnClickListener(v -> {
                RepositoryProvider.orders(requireContext()).updatePaymentStatus(p.getId(), "Paid");
                bindPayments();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 8);
            tv.setLayoutParams(lp);
            containerRecords.addView(tv);
        }
    }

    private void bindReports() {
        List<Order> orders = RepositoryProvider.orders(requireContext()).getAllOrders();
        long now = System.currentTimeMillis();
        double daily = 0, weekly = 0, monthly = 0, codTotal = 0, jcTotal = 0, epTotal = 0;
        int completed = 0, cancelled = 0;

        for (Order o : orders) {
            if (OrderStatus.CANCELLED.equalsIgnoreCase(o.getOrderStatus())) {
                cancelled++;
                continue;
            }
            if (OrderStatus.DELIVERED.equalsIgnoreCase(o.getOrderStatus())) {
                completed++;
            }
            long age = now - o.getCreatedAt();
            if (age <= 86400000L) daily += o.getTotalAmount();
            if (age <= 7L * 86400000L) weekly += o.getTotalAmount();
            if (age <= 30L * 86400000L) monthly += o.getTotalAmount();

            if (PaymentMethodConfig.METHOD_COD.equalsIgnoreCase(o.getPaymentMethod())) codTotal += o.getTotalAmount();
            else if (PaymentMethodConfig.METHOD_JAZZCASH.equalsIgnoreCase(o.getPaymentMethod())) jcTotal += o.getTotalAmount();
            else epTotal += o.getTotalAmount();
        }

        tvReports.setText(
                "SALES SUMMARY\n"
                        + "• Daily Sales (24h): " + CurrencyUtil.formatPkr(daily) + "\n"
                        + "• Weekly Sales (7d): " + CurrencyUtil.formatPkr(weekly) + "\n"
                        + "• Monthly Sales (30d): " + CurrencyUtil.formatPkr(monthly) + "\n\n"
                        + "ORDER OUTCOMES\n"
                        + "• Completed Orders: " + completed + "\n"
                        + "• Cancelled Orders: " + cancelled + "\n"
                        + "• Total Orders: " + orders.size() + "\n\n"
                        + "PAYMENT BREAKDOWN\n"
                        + "• Cash on Delivery: " + CurrencyUtil.formatPkr(codTotal) + "\n"
                        + "• JazzCash: " + CurrencyUtil.formatPkr(jcTotal) + "\n"
                        + "• EasyPaisa: " + CurrencyUtil.formatPkr(epTotal));
    }

    private void bindSettings() {
        RestaurantSettings s = RepositoryProvider.settings(requireContext()).getRestaurantSettings();
        if (s == null) return;
        etName.setText(s.getRestaurantName());
        etLogo.setText(s.getLogoUrl());
        etPhone.setText(s.getPhone());
        etWa.setText(s.getWhatsappNumber());
        etAddr.setText(s.getAddress());
        etOpen.setText(s.getOpeningHours());
        etClose.setText(s.getClosingHours());
        etDeliv.setText(String.valueOf(s.getDeliveryCharges()));
        etMin.setText(String.valueOf(s.getMinimumOrderAmount()));
    }

    private void saveSettings() {
        String name = etName.getText().toString().trim();
        if (!ValidationUtil.isNonEmpty(name)) {
            Toast.makeText(requireContext(), "Restaurant name required", Toast.LENGTH_SHORT).show();
            return;
        }
        double delivery, minOrder;
        try {
            delivery = Double.parseDouble(etDeliv.getText().toString().trim());
            minOrder = Double.parseDouble(etMin.getText().toString().trim());
        } catch (Exception e) {
            Toast.makeText(requireContext(), "Enter valid numeric charges", Toast.LENGTH_SHORT).show();
            return;
        }
        RestaurantSettings s = RepositoryProvider.settings(requireContext()).getRestaurantSettings();
        s.setRestaurantName(name);
        s.setLogoUrl(etLogo.getText().toString().trim());
        s.setPhone(etPhone.getText().toString().trim());
        s.setWhatsappNumber(etWa.getText().toString().trim());
        s.setAddress(etAddr.getText().toString().trim());
        s.setOpeningHours(etOpen.getText().toString().trim());
        s.setClosingHours(etClose.getText().toString().trim());
        s.setDeliveryCharges(delivery);
        s.setMinimumOrderAmount(minOrder);
        RepositoryProvider.settings(requireContext()).saveRestaurantSettings(s);
        Toast.makeText(requireContext(), "Settings saved", Toast.LENGTH_SHORT).show();
    }
}
