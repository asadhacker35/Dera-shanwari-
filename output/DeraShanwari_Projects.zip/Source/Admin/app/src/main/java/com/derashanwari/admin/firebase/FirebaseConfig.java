package com.derashanwari.admin.firebase;

/**
 * Centralized Firebase Realtime Database, Auth, and FCM configuration layer.
 * In DEMO MODE, all repositories execute against DemoDatabaseManager.
 * Once google-services.json is placed in app/ and Firebase dependencies are enabled,
 * flip DEMO_MODE to false or wire FirebaseRepository implementations in RepositoryProvider.
 */
public final class FirebaseConfig {
    public static final boolean DEMO_MODE = true;

    // Firebase Realtime Database shared root nodes across Admin, Customer, and Rider apps
    public static final String NODE_PRODUCTS = "products";
    public static final String NODE_CATEGORIES = "categories";
    public static final String NODE_BANNERS = "banners";
    public static final String NODE_ORDERS = "orders";
    public static final String NODE_RIDERS = "riders";
    public static final String NODE_CUSTOMERS = "customers";
    public static final String NODE_ADMINS = "admins";
    public static final String NODE_PAYMENTS = "payments";
    public static final String NODE_PAYMENT_METHODS = "payment_methods";
    public static final String NODE_SETTINGS = "restaurant_settings";
    public static final String NODE_REWARDS = "rewards";
    public static final String NODE_CHATS = "order_chats";

    // FCM Notification Topics
    public static final String TOPIC_ADMIN_NEW_ORDERS = "admin_new_orders";
    public static final String TOPIC_CUSTOMER_PREFIX = "customer_";
    public static final String TOPIC_RIDER_PREFIX = "rider_";

    private FirebaseConfig() {}
}
