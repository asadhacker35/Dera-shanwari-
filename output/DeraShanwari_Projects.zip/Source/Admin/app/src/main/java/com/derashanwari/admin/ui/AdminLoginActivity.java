package com.derashanwari.admin.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.derashanwari.admin.MainActivity;
import com.derashanwari.admin.R;
import com.derashanwari.admin.model.AdminUser;
import com.derashanwari.admin.repository.AuthRepository;
import com.derashanwari.admin.repository.RepositoryProvider;

public class AdminLoginActivity extends AppCompatActivity {
    private EditText etIdentifier, etPin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        etIdentifier = findViewById(R.id.et_admin_identifier);
        etPin = findViewById(R.id.et_admin_pin);

        findViewById(R.id.btn_admin_login).setOnClickListener(v -> attemptLogin());
        findViewById(R.id.btn_demo_admin_quick).setOnClickListener(v -> {
            etIdentifier.setText("admin@derashanwari.pk");
            etPin.setText("123456");
            attemptLogin();
        });
    }

    private void attemptLogin() {
        String id = etIdentifier.getText().toString().trim();
        String pin = etPin.getText().toString().trim();
        RepositoryProvider.auth(this).loginAdmin(id, pin, new AuthRepository.AuthCallback<AdminUser>() {
            @Override
            public void onSuccess(AdminUser user) {
                Toast.makeText(AdminLoginActivity.this, "Welcome, " + user.getName(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(AdminLoginActivity.this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();
            }

            @Override
            public void onError(String message) {
                Toast.makeText(AdminLoginActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }
}
