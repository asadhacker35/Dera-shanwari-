package com.derashanwari.admin.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.derashanwari.admin.R;
import com.derashanwari.admin.model.Order;
import com.derashanwari.admin.util.CurrencyUtil;

import java.util.List;

public class AdminOrderAdapter extends RecyclerView.Adapter<AdminOrderAdapter.VH> {
    public interface OnOrderSelectListener {
        void onSelect(Order order);
    }

    private final List<Order> orders;
    private final OnOrderSelectListener listener;

    public AdminOrderAdapter(List<Order> orders, OnOrderSelectListener listener) {
        this.orders = orders;
        this.listener = listener;
    }

    public void updateOrders(List<Order> newOrders) {
        orders.clear();
        orders.addAll(newOrders);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_admin_order, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Order o = orders.get(position);
        h.orderId.setText(o.getOrderId() + " • " + CurrencyUtil.formatPkr(o.getTotalAmount()));
        h.status.setText(o.getOrderStatus());
        h.customer.setText(o.getCustomerName() + " (" + o.getCustomerPhone() + ")");
        h.meta.setText(o.getPaymentMethod() + " • "
                + (o.getRiderName() != null ? "Rider: " + o.getRiderName() : "Unassigned")
                + " • " + CurrencyUtil.formatDateTime(o.getCreatedAt()));
        h.itemView.setOnClickListener(v -> listener.onSelect(o));
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView orderId, status, customer, meta;

        VH(@NonNull View itemView) {
            super(itemView);
            orderId = itemView.findViewById(R.id.tv_order_id);
            status = itemView.findViewById(R.id.tv_order_status);
            customer = itemView.findViewById(R.id.tv_order_customer);
            meta = itemView.findViewById(R.id.tv_order_meta);
        }
    }
}
