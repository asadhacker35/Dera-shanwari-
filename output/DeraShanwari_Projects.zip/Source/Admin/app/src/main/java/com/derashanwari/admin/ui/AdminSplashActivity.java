package com.derashanwari.admin.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.derashanwari.admin.MainActivity;
import com.derashanwari.admin.R;
import com.derashanwari.admin.repository.RepositoryProvider;

public class AdminSplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_splash);
        RepositoryProvider.init(this);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing()) return;
            boolean loggedIn = RepositoryProvider.auth(this).getCurrentAdmin() != null;
            startActivity(new Intent(this, loggedIn ? MainActivity.class : AdminLoginActivity.class));
            finish();
        }, 800);
    }
}
