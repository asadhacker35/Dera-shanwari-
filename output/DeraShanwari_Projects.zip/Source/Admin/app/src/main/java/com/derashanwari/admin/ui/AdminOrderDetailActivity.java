package com.derashanwari.admin.ui;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.derashanwari.admin.R;
import com.derashanwari.admin.model.Order;
import com.derashanwari.admin.model.OrderItem;
import com.derashanwari.admin.model.OrderStatus;
import com.derashanwari.admin.model.Rider;
import com.derashanwari.admin.repository.RepositoryProvider;
import com.derashanwari.admin.util.CurrencyUtil;
import com.derashanwari.admin.util.ValidationUtil;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.ArrayList;
import java.util.List;

public class AdminOrderDetailActivity extends AppCompatActivity {
    public static final String EXTRA_ORDER_ID = "extra_order_id";

    private Order order;
    private Spinner spinnerStatus, spinnerRider;
    private List<Rider> riders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_order_detail);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        String orderId = getIntent().getStringExtra(EXTRA_ORDER_ID);
        order = RepositoryProvider.orders(this).getOrderById(orderId);
        if (order == null) {
            Toast.makeText(this, "Order not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        spinnerStatus = findViewById(R.id.spinner_order_status);
        spinnerRider = findViewById(R.id.spinner_assign_rider);

        bindOrder();
        setupSpinners();

        findViewById(R.id.btn_update_status).setOnClickListener(v -> {
            String newStatus = (String) spinnerStatus.getSelectedItem();
            RepositoryProvider.orders(this).updateOrderStatus(order.getOrderId(), newStatus);
            order = RepositoryProvider.orders(this).getOrderById(order.getOrderId());
            bindOrder();
            Toast.makeText(this, "Order status updated to " + newStatus, Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.btn_assign_rider).setOnClickListener(v -> {
            int pos = spinnerRider.getSelectedItemPosition();
            if (pos >= 0 && pos < riders.size()) {
                Rider chosen = riders.get(pos);
                RepositoryProvider.orders(this).assignRider(order.getOrderId(), chosen.getId(), chosen.getName());
                order = RepositoryProvider.orders(this).getOrderById(order.getOrderId());
                bindOrder();
                setupSpinners();
                Toast.makeText(this, "Assigned to " + chosen.getName(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void bindOrder() {
        ((TextView) findViewById(R.id.tv_order_header)).setText(
                order.getOrderId() + " • " + order.getOrderStatus());
        String riderLabel = ValidationUtil.isNonEmpty(order.getRiderName())
                ? order.getRiderName() : "Not Assigned";
        ((TextView) findViewById(R.id.tv_customer_info)).setText(
                "Customer: " + order.getCustomerName()
                        + "\nPhone: " + order.getCustomerPhone()
                        + "\nAddress: " + order.getDeliveryAddress()
                        + "\nPayment: " + order.getPaymentMethod() + " (" + order.getPaymentStatus() + ")"
                        + "\nAssigned Rider: " + riderLabel
                        + (ValidationUtil.isNonEmpty(order.getNotes()) ? "\nNotes: " + order.getNotes() : ""));

        StringBuilder sb = new StringBuilder();
        for (OrderItem item : order.getItems()) {
            sb.append(item.getQuantity()).append("x ")
                    .append(item.getProductName()).append(" = ")
                    .append(CurrencyUtil.formatPkr(item.getLineTotal())).append("\n");
        }
        sb.append("\nSubtotal: ").append(CurrencyUtil.formatPkr(order.getSubtotal()));
        sb.append("\nDelivery Fee: ").append(CurrencyUtil.formatPkr(order.getDeliveryFee()));
        sb.append("\nGrand Total: ").append(CurrencyUtil.formatPkr(order.getTotalAmount()));
        ((TextView) findViewById(R.id.tv_items_breakdown)).setText(sb.toString());
    }

    private void setupSpinners() {
        List<String> statuses = OrderStatus.allAdminStatuses();
        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, statuses);
        spinnerStatus.setAdapter(statusAdapter);
        int idx = statuses.indexOf(order.getOrderStatus());
        if (idx >= 0) spinnerStatus.setSelection(idx);

        riders = RepositoryProvider.riders(this).getActiveRiders();
        List<String> riderNames = new ArrayList<>();
        int selectedRiderIdx = 0;
        for (int i = 0; i < riders.size(); i++) {
            Rider r = riders.get(i);
            riderNames.add(r.getName() + " (" + r.getPhone() + ")");
            if (r.getId().equals(order.getRiderId())) {
                selectedRiderIdx = i;
            }
        }
        ArrayAdapter<String> riderAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, riderNames);
        spinnerRider.setAdapter(riderAdapter);
        if (!riderNames.isEmpty()) spinnerRider.setSelection(selectedRiderIdx);
    }
}
