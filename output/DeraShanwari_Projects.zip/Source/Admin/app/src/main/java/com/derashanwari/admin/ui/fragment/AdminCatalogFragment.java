package com.derashanwari.admin.ui.fragment;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.derashanwari.admin.R;
import com.derashanwari.admin.model.Banner;
import com.derashanwari.admin.model.Category;
import com.derashanwari.admin.model.Product;
import com.derashanwari.admin.repository.ProductRepository;
import com.derashanwari.admin.repository.RepositoryProvider;
import com.derashanwari.admin.ui.adapter.AdminCatalogAdapter;
import com.derashanwari.admin.util.CurrencyUtil;
import com.derashanwari.admin.util.ValidationUtil;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class AdminCatalogFragment extends Fragment {
    private static final int TAB_PRODUCTS = 0;
    private static final int TAB_CATEGORIES = 1;
    private static final int TAB_BANNERS = 2;

    private int currentTab = TAB_PRODUCTS;
    private ProductRepository repo;
    private AdminCatalogAdapter adapter;
    private MaterialButton btnProducts, btnCategories, btnBanners;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_admin_catalog, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        repo = RepositoryProvider.products(requireContext());

        btnProducts = view.findViewById(R.id.btn_tab_products);
        btnCategories = view.findViewById(R.id.btn_tab_categories);
        btnBanners = view.findViewById(R.id.btn_tab_banners);

        RecyclerView rv = view.findViewById(R.id.rv_catalog);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new AdminCatalogAdapter(new ArrayList<>(), new AdminCatalogAdapter.OnCatalogActionListener() {
            @Override
            public void onEdit(String id) {
                if (currentTab == TAB_PRODUCTS) showProductDialog(repo.getProductById(id));
                else if (currentTab == TAB_CATEGORIES) showCategoryDialog(findCategory(id));
                else showBannerDialog(findBanner(id));
            }

            @Override
            public void onDelete(String id) {
                if (currentTab == TAB_PRODUCTS) repo.deleteProduct(id);
                else if (currentTab == TAB_CATEGORIES) repo.deleteCategory(id);
                else repo.deleteBanner(id);
                refresh();
                Toast.makeText(requireContext(), "Item deleted", Toast.LENGTH_SHORT).show();
            }
        });
        rv.setAdapter(adapter);

        btnProducts.setOnClickListener(v -> switchTab(TAB_PRODUCTS));
        btnCategories.setOnClickListener(v -> switchTab(TAB_CATEGORIES));
        btnBanners.setOnClickListener(v -> switchTab(TAB_BANNERS));

        view.findViewById(R.id.fab_add_catalog).setOnClickListener(v -> {
            if (currentTab == TAB_PRODUCTS) showProductDialog(null);
            else if (currentTab == TAB_CATEGORIES) showCategoryDialog(null);
            else showBannerDialog(null);
        });

        switchTab(TAB_PRODUCTS);
    }

    private void switchTab(int tab) {
        currentTab = tab;
        int active = ContextCompat.getColor(requireContext(), R.color.admin_orange);
        int idle = ContextCompat.getColor(requireContext(), R.color.admin_surface_elevated);
        btnProducts.setBackgroundColor(tab == TAB_PRODUCTS ? active : idle);
        btnCategories.setBackgroundColor(tab == TAB_CATEGORIES ? active : idle);
        btnBanners.setBackgroundColor(tab == TAB_BANNERS ? active : idle);
        refresh();
    }

    private void refresh() {
        List<AdminCatalogAdapter.CatalogRow> rows = new ArrayList<>();
        if (currentTab == TAB_PRODUCTS) {
            for (Product p : repo.getAllProducts()) {
                String priceStr = CurrencyUtil.formatPkr(p.getEffectivePrice())
                        + (p.hasDiscount() ? " (was " + CurrencyUtil.formatPkr(p.getPrice()) + ")" : "");
                rows.add(new AdminCatalogAdapter.CatalogRow(
                        p.getId(), p.getName(),
                        p.getCategoryName() + " • " + (p.isAvailable() ? "Available" : "Unavailable")
                                + (p.isFeatured() ? " • Featured" : ""),
                        priceStr, p.getImageUrl(), p.getLocalDrawableName()));
            }
        } else if (currentTab == TAB_CATEGORIES) {
            for (Category c : repo.getAllCategories()) {
                rows.add(new AdminCatalogAdapter.CatalogRow(
                        c.getId(), c.getName(),
                        c.isAvailable() ? "Visible in Customer Menu" : "Hidden",
                        "Order #" + c.getSortOrder(), c.getImageUrl(), c.getLocalDrawableName()));
            }
        } else {
            for (Banner b : repo.getAllBanners()) {
                rows.add(new AdminCatalogAdapter.CatalogRow(
                        b.getId(), b.getTitle(), b.getSubtitle(),
                        b.isActive() ? "Active Banner" : "Inactive",
                        b.getImageUrl(), b.getLocalDrawableName()));
            }
        }
        adapter.updateRows(rows);
    }

    private Category findCategory(String id) {
        for (Category c : repo.getAllCategories()) if (c.getId().equals(id)) return c;
        return null;
    }

    private Banner findBanner(String id) {
        for (Banner b : repo.getAllBanners()) if (b.getId().equals(id)) return b;
        return null;
    }

    private void showProductDialog(@Nullable Product existing) {
        View v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_product, null);
        EditText etName = v.findViewById(R.id.et_prod_name);
        EditText etDesc = v.findViewById(R.id.et_prod_desc);
        EditText etPrice = v.findViewById(R.id.et_prod_price);
        EditText etDisc = v.findViewById(R.id.et_prod_discount);
        EditText etImg = v.findViewById(R.id.et_prod_image);
        Spinner spCat = v.findViewById(R.id.spinner_prod_category);
        SwitchCompat swAvail = v.findViewById(R.id.sw_prod_available);
        SwitchCompat swFeat = v.findViewById(R.id.sw_prod_featured);
        SwitchCompat swPop = v.findViewById(R.id.sw_prod_popular);

        List<Category> cats = repo.getAllCategories();
        List<String> catNames = new ArrayList<>();
        int selCat = 0;
        for (int i = 0; i < cats.size(); i++) {
            catNames.add(cats.get(i).getName());
            if (existing != null && cats.get(i).getId().equals(existing.getCategoryId())) selCat = i;
        }
        spCat.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, catNames));
        if (!catNames.isEmpty()) spCat.setSelection(selCat);

        if (existing != null) {
            etName.setText(existing.getName());
            etDesc.setText(existing.getDescription());
            etPrice.setText(String.valueOf(existing.getPrice()));
            etDisc.setText(String.valueOf(existing.getDiscountPrice()));
            etImg.setText(existing.getImageUrl());
            swAvail.setChecked(existing.isAvailable());
            swFeat.setChecked(existing.isFeatured());
            swPop.setChecked(existing.isPopular());
        }

        new AlertDialog.Builder(requireContext())
                .setTitle(existing == null ? "Add Product" : "Edit Product")
                .setView(v)
                .setPositiveButton("Save", (d, w) -> {
                    String name = etName.getText().toString().trim();
                    if (!ValidationUtil.isNonEmpty(name)) {
                        Toast.makeText(requireContext(), "Product name required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    double price, disc = 0;
                    try {
                        price = Double.parseDouble(etPrice.getText().toString().trim());
                        String discTxt = etDisc.getText().toString().trim();
                        if (!discTxt.isEmpty()) disc = Double.parseDouble(discTxt);
                    } catch (Exception e) {
                        Toast.makeText(requireContext(), "Enter valid numeric prices", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (!ValidationUtil.isValidPrice(price) || !ValidationUtil.isValidDiscountPrice(price, disc)) {
                        Toast.makeText(requireContext(), "Invalid price or discount >= price", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Category chosenCat = cats.isEmpty() ? null : cats.get(spCat.getSelectedItemPosition());
                    Product p = existing != null ? existing : new Product();
                    p.setName(name);
                    p.setDescription(etDesc.getText().toString().trim());
                    p.setPrice(price);
                    p.setDiscountPrice(disc);
                    p.setImageUrl(etImg.getText().toString().trim());
                    if (p.getLocalDrawableName() == null || p.getLocalDrawableName().isEmpty()) {
                        p.setLocalDrawableName("img_banner_shanwari");
                    }
                    if (chosenCat != null) {
                        p.setCategoryId(chosenCat.getId());
                        p.setCategoryName(chosenCat.getName());
                    }
                    p.setAvailable(swAvail.isChecked());
                    p.setFeatured(swFeat.isChecked());
                    p.setPopular(swPop.isChecked());
                    repo.saveProduct(p);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showCategoryDialog(@Nullable Category existing) {
        View v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_category, null);
        EditText etName = v.findViewById(R.id.et_cat_name);
        EditText etImg = v.findViewById(R.id.et_cat_image);
        SwitchCompat swAvail = v.findViewById(R.id.sw_cat_available);
        if (existing != null) {
            etName.setText(existing.getName());
            etImg.setText(existing.getImageUrl());
            swAvail.setChecked(existing.isAvailable());
        }
        new AlertDialog.Builder(requireContext())
                .setTitle(existing == null ? "Add Category" : "Edit Category")
                .setView(v)
                .setPositiveButton("Save", (d, w) -> {
                    String name = etName.getText().toString().trim();
                    if (!ValidationUtil.isNonEmpty(name)) {
                        Toast.makeText(requireContext(), "Category name required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Category c = existing != null ? existing : new Category();
                    c.setName(name);
                    c.setImageUrl(etImg.getText().toString().trim());
                    if (c.getLocalDrawableName() == null) c.setLocalDrawableName("img_food_tikka_bbq");
                    c.setAvailable(swAvail.isChecked());
                    if (c.getSortOrder() <= 0) c.setSortOrder(repo.getAllCategories().size() + 1);
                    repo.saveCategory(c);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showBannerDialog(@Nullable Banner existing) {
        View v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_banner, null);
        EditText etTitle = v.findViewById(R.id.et_ban_title);
        EditText etSub = v.findViewById(R.id.et_ban_subtitle);
        EditText etImg = v.findViewById(R.id.et_ban_image);
        SwitchCompat swActive = v.findViewById(R.id.sw_ban_active);
        if (existing != null) {
            etTitle.setText(existing.getTitle());
            etSub.setText(existing.getSubtitle());
            etImg.setText(existing.getImageUrl());
            swActive.setChecked(existing.isActive());
        }
        new AlertDialog.Builder(requireContext())
                .setTitle(existing == null ? "Add Banner" : "Edit Banner")
                .setView(v)
                .setPositiveButton("Save", (d, w) -> {
                    String title = etTitle.getText().toString().trim();
                    if (!ValidationUtil.isNonEmpty(title)) {
                        Toast.makeText(requireContext(), "Banner title required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Banner b = existing != null ? existing : new Banner();
                    b.setTitle(title);
                    b.setSubtitle(etSub.getText().toString().trim());
                    b.setImageUrl(etImg.getText().toString().trim());
                    if (b.getLocalDrawableName() == null) b.setLocalDrawableName("img_banner_shanwari");
                    b.setActive(swActive.isChecked());
                    if (b.getSortOrder() <= 0) b.setSortOrder(repo.getAllBanners().size() + 1);
                    repo.saveBanner(b);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
