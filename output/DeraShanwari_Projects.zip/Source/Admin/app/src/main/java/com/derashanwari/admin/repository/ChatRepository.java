package com.derashanwari.admin.repository;

import com.derashanwari.admin.model.ChatMessage;

import java.util.List;

public interface ChatRepository {
    List<ChatMessage> getMessagesForOrder(String orderId);
    void sendMessage(ChatMessage message);
}
