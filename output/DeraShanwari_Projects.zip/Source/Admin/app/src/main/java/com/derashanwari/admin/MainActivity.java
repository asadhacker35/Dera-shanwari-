package com.derashanwari.admin;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.derashanwari.admin.repository.RepositoryProvider;
import com.derashanwari.admin.ui.fragment.AdminCatalogFragment;
import com.derashanwari.admin.ui.fragment.AdminDashboardFragment;
import com.derashanwari.admin.ui.fragment.AdminMoreFragment;
import com.derashanwari.admin.ui.fragment.AdminOrdersFragment;
import com.derashanwari.admin.ui.fragment.AdminPeopleFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_main);
        RepositoryProvider.init(this);

        BottomNavigationView nav = findViewById(R.id.admin_bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_admin_dashboard) {
                load(new AdminDashboardFragment());
                return true;
            } else if (id == R.id.nav_admin_catalog) {
                load(new AdminCatalogFragment());
                return true;
            } else if (id == R.id.nav_admin_orders) {
                load(new AdminOrdersFragment());
                return true;
            } else if (id == R.id.nav_admin_people) {
                load(new AdminPeopleFragment());
                return true;
            } else if (id == R.id.nav_admin_more) {
                load(new AdminMoreFragment());
                return true;
            }
            return false;
        });

        if (savedInstanceState == null) {
            nav.setSelectedItemId(R.id.nav_admin_dashboard);
        }
    }

    private void load(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.admin_fragment_container, fragment)
                .commit();
    }
}
